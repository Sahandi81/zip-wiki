@extends('layouts.app')

@section('title', 'صفحه اصلی')

@section('content')

    <div class="hero-area position-relative" style="padding-bottom: 0;">
        <div>
            <div class="swiper-slide hero-slide-item pb-lg-0 pb-5">
                <div class="container">
                    <div class="row d-flex align-items-center">
                        <div class="col-lg-6 offset-lg-1">
                            <div class="slide-item-content text-lg-end text-center">
                                <h1 class="header-title text-light fw-bold header-texts">WIkIInflu</h1>
                                <h4 class="header-sub-title header-texts">اولین و جامع ترین مرجع<br> اینفلوئنسرهای
                                    ایرانی در شبکه های اجتماعی</h4>

                            </div>
                        </div>
                        <div class="col-lg-5 d-flex justify-content-center">
                            <div class="profile-header-image-area mt-5 mb-0 d-lg-flex d-none justify-content-lg-end">
                                <img src="{{asset('images/site-image/about-us/about-header.svg')}}" alt="profile header image"
                                     class="img-fluid profile-header-image figure">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    @include('hemayat')


    <main>
        <div class="about-wrapper mt-120">
            <div class="container">
                <div class="about-details">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="details-image">
                                <img src="{{asset('images/site-image/about-us/about-welcome.svg')}}" alt="" class="img-fluid">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="details-discription">
                                <h5>درباره ما</h5>
                                <h3>به شبکه اینفلوئنسری ایران خوش آمدید</h3>
                                <strong>امروز را برای یک آینده بزرگ شروع کنید</strong>
                                <p>
                                    اینجا یک مرجع تخصصی معرفی، آنالیز، آموزش و آسیب شناسی در زمینه اینفلوئنسری و در عین
                                    حال همکاری اینفلوئنسرمارکتینگ به صورت حرفه ای و با افراد ارزشمند می باشد.
                                </p>
                                <div class="mt-5 about-sub-titrs d-flex justify-content-between align-items-center">
                                    <div class="d-flex align-items-center justify-content-center">
                                        <div class="ms-3">
                                            <img src="{{asset('/images/site-image/about-us/wiki-age.svg')}}" alt="wiki age">
                                        </div>
                                         <div>
                                            <h3 class="fw-bolder" style="color: #8EC751; font-size: 25px;">10</h3>
                                            <h4>پشتیبانی</h4>
                                        </div>
                                    </div>
                                    <div class="d-flex align-items-center justify-content-center">
                                        <div class="ms-3">
                                            <img src="{{asset('/images/site-image/about-us/insta-influ.svg')}}" alt="insta influ">
                                        </div>
                                        <div>
                                            <h3 class="fw-bolder" style="color: #FF998E; font-size: 25px;">90</h3>
                                            <h4>رضایت مشتریان</h4>
                                        </div>
                                    </div>
                                    <div class="d-flex align-items-center justify-content-center">
                                        <div class="ms-3">
                                            <img src="{{asset('/images/site-image/about-us/youtube-influ.svg')}}" alt="youtube influ">
                                        </div>
                                        <div>
                                            <h3 class="fw-bolder" style="color: #B89FC6; font-size: 25px;">20</h3>
                                            <h4>اینفلوئنسر فعال</h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="about-history mt-96">
                    <div class="row flex-lg-row flex-column-reverse">
                        <div class="col-lg-6 col-12">
                            <div class="history-discription mt-24">
                                <h4>با ما همراه باشید</h4>
                                <p>
                                    این قسمت مربوط به معرفی اینفلوئنسر های اینستاگرام،یوتیوب و محتوا هایی در قالب بلاگ و اخبار که در زمینه اینفلوئنسری وجود داره و به صورت کارشناسی با شما در بارش صحبت می کنیم.
                                </p>
                            </div>
                            <div class="about-d-btn mt-5">
                                <a href="{{ url('categories?type=instagram&kind=mega') }}" class="primary-btn-md ms-3">اینستاگرام</a>
                                <a href="{{ url('blog') }}" class="primary-btn-l ms-3 mt-sm-0 mt-3">آخرین اخبار</a>
                                <a href="{{ url('categories?type=youtube') }}" class="primary-btn-md mt-sm-0 mt-3">یوتیوب</a>

                            </div>
                        </div>
                        <div class="col-lg-6 col-md-9">
                            <img class="img-fluid"
                                 src="{{asset('/images/site-image/about-us/about-help.svg')}}" alt="">

                        </div>
                    </div>
                </div>

            </div>
        </div>
    </main>

@endsection