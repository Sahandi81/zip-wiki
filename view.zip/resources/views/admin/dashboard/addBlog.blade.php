@extends('admin.layouts.master')

@section('title', 'افزودن بلاگ')

@section('content')

    <div class="page-wrapper">
        <div class="page-content">

            <!--breadcrumb-->
{{--            <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">--}}
{{--                <div class="breadcrumb-title pe-3">داشبورد</div>--}}
{{--                <div class="ps-3">--}}
{{--                    <nav aria-label="breadcrumb">--}}
{{--                        <ol class="breadcrumb mb-0 p-0">--}}
{{--                            <li class="breadcrumb-item"><a href="blog-list-page.html">بلاگ و اخبار کلی سایت</a>--}}
{{--                            </li>--}}
{{--                            <li class="breadcrumb-item active" aria-current="page">اضافه کردن بلاگ و اخبار جدید</li>--}}
{{--                        </ol>--}}
{{--                    </nav>--}}
{{--                </div>--}}
{{--            </div>--}}
            <!--end breadcrumb-->

            <div class="card">
                <div class="card-body p-4">
                    <h5 class="card-title">اضافه کردن بلاگ و اخبار جدید</h5>
                    <hr />
                    <div class="form-body mt-4">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="border border-3 p-4 rounded">
                                    <form action="" method="POST" enctype="multipart/form-data">
                                        @csrf
                                        <div class="row g-3">

                                        <h6 class="mb-0">جزئیات کلی صفحه بلاگ یا اخبار</h6>
                                        <hr>

                                        <div class="col-12">
                                            <label class="form-label">عنوان بلاگ یا
                                                اخبار</label>
                                            <input  type="text" maxlength="50" name="title" class="form-control" id="inputCompareatprice">
                                        </div>
                                        <div class="col-12">
                                            <label class="form-label">تصویر کلی بلاگ یا
                                                اخبار</label>
                                            <!-- Upload  -->
{{--                                            <input type="file" name="header_image">--}}
                                            <div class="uploader">
                                                <input id="file-upload" type="file" name="fileUpload"
                                                       accept="image/*" />

                                                <label for="file-upload"
                                                       class="d-flex justify-content-center align-items-center"
                                                       id="file-drag">
                                                    <img id="file-image" src="#" alt="Preview" class="hidden">
                                                    <div id="start">
                                                        <i class="fa fa-download" aria-hidden="true-fill"></i>
                                                        <div>تصویر خود را اینجا رها کنید</div>
                                                        <div id="notimage" class="hidden"> تصویری انتخاب کنید </div>
                                                        <span id="file-upload-btn" class="btn btn-primary">انتخاب</span>
                                                    </div>
                                                    <div id="response" class="hidden">
                                                        <div id="messages"></div>
                                                        <progress class="progress" id="file-progress" value="0">
                                                            <span>0</span>%
                                                        </progress>
                                                    </div>
                                                </label>
                                            </div>
                                        </div>

                                        <div class="col-12 mb-3">
                                            <label class="form-label">سرتیتر کلی بلاگ یا
                                                اخبار</label>
                                            <input class="form-control" type="text" maxlength="50" name="slug" id="inputProductDescription">
                                        </div>


                                        <div class="col-12 mb-3">
                                            <label class="form-label"> نویسنده </label>
                                            <input class="form-control" type="text" maxlength="50" name="nevisande" id="inputProductDescription">
                                        </div>

                                            <div class="col-md-6 mb-md-3">
                                                <label for="inputProductType" class="form-label requierd">دسته بندی
                                                    بلاگ</label>
                                                <select class="form-select" name="category" id="inputProductType">
                                                    <option></option>
                                                    @foreach(\App\Models\BlogCategory::all() as $blogCategory)
                                                        <option value="{{ $blogCategory->id }}">{{ $blogCategory->name }}</option>
                                                    @endforeach
                                                </select>
                                            </div>

                                        <div class="col-12 mb-3">
                                            <label class="form-label">متن کلی بلاگ یا اخبار</label>
                                            <textarea name="body" id="editor"></textarea>
                                        </div>
                                        <hr>

                                            <div class="col-md-6 mb-md-3">
                                                <label for="inputProductType" class="form-label"> مربوط به : </label>
                                                <select class="form-select" name="influencer_id" id="inputProductType">
                                                    <option value="0"> عمومی </option>
                                                    @foreach(\App\Models\Influencer::all()->sortBy('f_name') as $influencer)
                                                    <option value="{{ $influencer->id }}"> {{ $influencer->f_name }} </option>
                                                    @endforeach
                                                </select>
                                            </div>

                                        <hr>

                                        <div class=" d-flex flex-row-reverse">
                                            <button type="submit" class="btn btn-primary">ذخیره اطلاعات</button>
                                        </div>

                                    </div>
                                    </form>
                                </div>
                            </div>

                        </div>
                        <!--end row-->
                    </div>
                </div>
            </div>

        </div>
    </div>


@endsection