@extends('admin.layouts.master')

@section('title', 'افزودن بلاگ')

@section('content')


<div class="page-wrapper">
    <div class="page-content">

        @if(\Illuminate\Support\Facades\Session::has('deleted'))
            <div class="alert alert-danger d-flex align-items-center" role="alert">
                <svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Danger:"><use xlink:href="#exclamation-triangle-fill"/></svg>
                <div>
                    با موفقیت حذف شد.
                </div>
            </div>
        @endif

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex flex-sm-row flex-column-reverse justify-content-between align-items-sm-center">
                            <div class="d-flex mt-sm-0 mt-3">
                                <button type="button" class="btn me-1 btn-outline-primary"><i class="bx bx-filter-alt me-0-fill"></i>
                                </button>
                                <a href="{{ url()->route('admin.blog.index') }}" class="btn me-1 btn-outline-primary"><i class="bx bx-plus me-0-fill"></i>
                                </a>
                            </div>
                            <div>
                                <form action="#" class="d-flex">
                                    <div class="input-group">
                                        <input type="text" class="form-control" placeholder="جستجو">
                                        <button class="btn search-button" type="submit"><i class="bx bx-search-fill"></i>
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-3 row-cols-xl-4">
            @foreach(\App\Models\Blog::all()->sortDesc() as $blog)
                <div class="col">
                    <div class="blog-card shadow">
                        <div class="blog-thumb">
                            @if(!empty($blog->photo) && ($blog->photo) != 'blogs/')
                            <a href="#"><img src="{{ \Illuminate\Support\Facades\Storage::url($blog->photo) }}" alt=""></a>
                            @endif
                        </div>
                        <div class="blog-content">
                            <div class="blog-top">
                                <div class="blog-tags">
                                    <a href="#">{{ $blog->title }}</a>
                                </div>
                            </div>
                            <h3 class="blog-title"><a href="{{ url()->route('admin.blog.edit', ['id' => $blog->id]) }}">{{ $blog->slug }}</a></h3>
                            <div class="blog-bottom d-flex justify-content-between align-items-center">
                                <div class="blog-writer-link"><a><span> {{ jdate(strtotime($blog->created_at))->format('d F Y') }}  </span></a></div>
                                <div class="d-flex pt-2 justify-content-center align-items-center">
                                    <a href="{{ url()->route('delete.blog', ['id' => $blog->id]) }}" class="link-secondary fs-4 me-2"><i class="bi bi-x"></i></a>
                                    <a class="link-secondary fs-6" href="{{ url()->route('admin.blog.edit', ['id' => $blog->id]) }}">
                                        <i class="bi bi-pen-fill"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</div>

@endsection