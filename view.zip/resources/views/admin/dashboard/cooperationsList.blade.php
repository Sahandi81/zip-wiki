@extends('admin.layouts.master')

@section('title', 'اینفلوئنسر توصیه شده')

@section('content')

    <div class="page-wrapper" xmlns="http://www.w3.org/1999/html">
        @if(\Illuminate\Support\Facades\Session::has('delete'))
            <div class="alert alert-danger d-flex align-items-center" role="alert">
                <svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Danger:"><use xlink:href="#exclamation-triangle-fill"/></svg>
                <div>
                    با موفقیت حذف شد.
                </div>
            </div>
        @endif
        @if(\Illuminate\Support\Facades\Session::has('verify'))
            <div class="alert alert-success d-flex align-items-center" role="alert">
                <svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Danger:"><use xlink:href="#exclamation-triangle-fill"/></svg>
                <div>
                    با موفقیت تایید شد.
                </div>
            </div>
        @endif
        <div class="page-content">
            <div class="row">
                <div class="col-12">
                    <h5 class="card-title"> درخواست های همکاری </h5>
                    <hr>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="d-flex flex-sm-row flex-column-reverse justify-content-between align-items-sm-center">
                                <div class="d-flex mt-sm-0 mt-3">
                                    <button type="button" class="btn me-1 btn-outline-primary"><i class="bx bx-filter-alt me-0-fill"></i>
                                    </button>
                                </div>
                                <div>
                                    <form action="#" class="d-flex">
                                        <div class="input-group">
                                            <input type="text" class="form-control" placeholder="جستجو">
                                            <button class="btn search-button" type="submit"><i class="bx bx-search-fill"></i>
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row row-cols-1 row-cols-lg-2 row-cols-xl-3">

                @foreach($cooperations->toArray() as $cooperation)
                    <div class="col">
                        <div class="card radius-10">
                            <div class="card-body">
                                <div class="d-flex align-items-center">
                                    <div class="flex-grow-1 d-flex align-items-center">
                                        <a class="link-secondary fs-6 mt-1" data-bs-toggle="collapse"
                                           href="#cooperation{{ $cooperation['id'] }}" role="button" aria-expanded="false"
                                           aria-controls="cooperation{{ $cooperation['id'] }}">
                                            <i class="bi bi-caret-down-fill"></i>
                                        </a>
{{--                                        <small class="p-1 text-success">--}}
{{--                                        @if($cooperation['verified'])--}}
{{--                                            {{ 'تایید شده' }}--}}
{{--                                        @endif--}}
                                        </small>
                                    </div>
                                    <h5 class="font-weight-bold mb-0 me-4">{{ $cooperation['user']['name'] ?? 'ناشناس' }} </h5>
                                    <div class="widgets-icons bg-gradient-cosmic text-white">
                                        <i class="bx bx-user-fill"></i>
                                    </div>

                                </div>
                            </div>
                            <div class="collapse" id="cooperation{{ $cooperation['id'] }}">
                                <div class="card-body d-flex flex-column">

                                   @foreach($cooperation as $key => $item)
                                    @if(!is_string($item))
                                        @continue
                                    @endif
                                       <div class="d-flex justify-content-around float-end">
                                            <b> {{ $key }} </b> <span> {{ $item }} </span> <br>
                                       </div>
                                    @endforeach

                            </div>
                        </div>
                    </div>
                    </div>
                @endforeach

                </div>
            </div>
        </div>
    </div


@endsection