@extends('admin.layouts.master')

@section('title', 'ویرایش کاربران')

@section('content')

    <div class="page-wrapper">
        <div class="page-content">

            <div class="card">
                <div class="card-body p-4">
                    <h5 class="card-title">اضافه کردن اینفلوئنسر</h5>
                    <hr />
                    <form method="POST" action="" enctype="multipart/form-data">
                        @csrf
                        <div class="form-body mt-4">
                        <div class="row">
                            <div class="col-12">
                                <div class="border border-3 p-4 rounded">
                                    <div class="row g-3">


                                        <h6 class="mb-0">اطلاعات کسب و کار</h6>
                                        <hr>

                                        <div class="col-12 d-flex align-items-center">
                                            <input id="image-uploadify" type="file"
                                                   accept=".xlsx,.xls,image/*,.doc,audio/*,.docx,video/*,.ppt,.pptx,.txt,.pdf"
                                                   multiple>
                                        </div>
                                        <div class="col-md-6">
                                            <label for="inputPrice" class="form-label requierd">نام و نام
                                                خانوادگی</label>
                                            <input type="text" name="f_name" class="form-control" id="inputPrice">
                                        </div>
                                        <div class="col-md-6">
                                            <label for="inputCompareatprice" class="form-label requierd">شماره
                                                تلفن</label>
                                            <input type="tel" class="form-control" name="phone" id="inputCompareatprice">
                                        </div>
                                        <div class="col-md-6">
                                            <label for="inputCostPerPrice"
                                                   class="form-label requierd">یوزرنیم</label>
                                            <input type="text" name="username" class="form-control" id="inputCostPerPrice">
                                        </div>
                                        <div class="col-md-6">
                                            <label for="inputStarPoints" class="form-label requierd">ایمیل</label>
                                            <input type="email" name="email" class="form-control" id="inputStarPoints">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">آدرس سایت</label>
                                            <input type="url" name="website" class="form-control">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">آیدی تلگرام</label>
                                            <input type="text" name="telegram_id" class="form-control">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label requierd">آیدی اینستاگرام</label>
                                            <input type="text" name="insta_id" class="form-control">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">فیسبوک</label>
                                            <input type="text" name="fb_id" class="form-control">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">توییت</label>
                                            <input type="text" name="twitter_id" class="form-control">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label requierd">محل سکونت</label>
                                            <select name="city" class="form-select" id="">
                                                <option value="" selected disabled> انتخاب کنید </option>
                                                @foreach(\App\Models\Map::all() as $map)
                                                    <option value="{{ $map->en }}"> {{ $map->fn }} </option>
                                                @endforeach
                                            </select>
                                        </div>
{{--                                        <div class="col-12">--}}
{{--                                            <div class="form-check">--}}
{{--                                                <label class="form-check-label" for="flexCheckDefault">--}}
{{--                                                    آیا اکانت فعال شده است؟--}}
{{--                                                </label>--}}
{{--                                                <input class="form-check-input" type="checkbox" value=""--}}
{{--                                                       id="flexCheckDefault">--}}

{{--                                            </div>--}}
{{--                                        </div>--}}

                                        <h6 class="mb-0 mt-5 requierd">درباره اینفلوئنسر</h6>
                                        <hr>
                                        <div class="col-12 mb-3">
                                            <textarea name="about" id="editor"></textarea>
                                        </div>

                                        <hr>

                                        <div class="col-md-6 mb-md-3">
                                            <label for="inputProductType" class="form-label requierd">حوضه فعالیت
                                                اینفلوئنسر</label>
                                            <select class="form-select" name="type" id="inputProductType">
                                                <option></option>
                                                <option value="youtube">یوتیوب</option>
                                                <option value="instagram">اینستاگرام</option>
                                            </select>
                                        </div>

                                        <div class="col-md-6 mb-md-3">
                                            <label for="inputProductType" class="form-label requierd">دسته بندی
                                                اینفلوئنسر</label>
                                            <select class="form-select" name="kind" id="inputProductType">
                                                <option></option>
                                                <option value="mega">مگا</option>
                                                <option value="macro">ماکرو</option>
                                                <option value="mid">میدل</option>
                                                <option value="micro">میکرو</option>
                                                <option value="nano">نانو</option>
                                            </select>
                                        </div>

                                        <hr>

                                        <div class="col-12">
                                            <p><b>
                                            دسته بندی اینستاگرام:
                                            </b></p>
                                            @foreach(\App\Models\Category::where('type', 'instagram')->get()->toArray() as $key => $category)
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" name="{{ $category['id'] }}" type="checkbox" id="inlineCheckbox{{ $category['id'] }}"
                                                       value="{{ $category['id'] }}">
                                                <label class="form-check-label" for="inlineCheckbox{{ $category['id'] }}">{{ $category['name'] }}</label>
                                            </div>
                                            @endforeach
                                        </div>

                                        <hr>

                                        <div class="col-12">
                                            <p><b>
                                            دسته بندی یوتیوب:
                                            </b></p>
                                            @foreach(\App\Models\Category::where('type', 'youtube')->get()->toArray() as $key => $category)
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" name="{{ $category['id'] }}" type="checkbox" id="inlineCheckbox{{ $category['id'] }}"
                                                           value="{{ $category['id'] }}">
                                                    <label class="form-check-label" for="inlineCheckbox{{ $category['id'] }}">{{ $category['name'] }}</label>
                                                </div>
                                            @endforeach
                                        </div>

                                        <hr>
                                        <div class="col-md-3">
                                            <label class="form-label">هشتگ و تیکه کلام</label>
                                            <br>
                                            <small class="small">کلمات با # از هم جدا شوند.</small>
                                            <br>
                                            <small class="small">بیشتر از ۴ مورد نوشته نشوند.</small>
                                            <input type="text" name="hashtag" value=""
                                                   class="form-control">
                                        </div>
                                        <hr>

                                        <div class=" d-flex flex-row-reverse">
                                            <button type="submit" class="btn btn-primary">ذخیره اطلاعات</button>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--end row-->
                    </div>
                    </form>
                </div>
            </div>

        </div>
    </div>

@endsection