@extends('admin.layouts.master')

@section('title', 'ویرایش کاربران')

@section('content')

    <div class="page-wrapper">
        <div class="page-content">

            <div class="card">
                <div class="card-body p-4">
                    <h5 class="card-title">اضافه کردن اینفلوئنسر</h5>
                    <hr />
                    @if(\Illuminate\Support\Facades\Session::has('deleted_post'))
                        <div class="alert alert-danger d-flex align-items-center" role="alert">
                            <svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Danger:"><use xlink:href="#exclamation-triangle-fill"/></svg>
                            <div>
                                پست مورد نظر حذف شد.
                            </div>
                        </div>
                    @endif
                    <form method="POST" action="{{ url()->route('admin.add.influencers') }}" enctype="multipart/form-data">
                        @csrf
                        <input type="hidden" name="id" value="{{ $influ->id }}">
                        <div class="form-body mt-4">
                        <div class="row">
                            <div class="col-12">
                                <div class="border border-3 p-4 rounded">
                                    <div class="row g-3">


                                        <h6 class="mb-0">اطلاعات کسب و کار</h6>
                                        <hr>

                                        <div class="col-12 d-flex align-items-center">
                                            <a class="users-profile fs-5 " href="#">
                                                <i class="bi bi-pen mt-2-fill"></i>
                                                <input type="file" name="photo">
                                            </a>
                                            @if(!empty($influ->photo) && ($influ->photo) != 'profiles/')
                                                <img src="{{ \Illuminate\Support\Facades\Storage::url($influ->photo) }}" height="100" width="100" alt="">
                                            @endif
                                        </div>
                                        <div class="col-md-6">
                                            <label for="inputPrice" class="form-label requierd">نام و نام
                                                خانوادگی</label>
                                            <input type="text" name="f_name" value="{{ $influ->f_name }}" class="form-control" id="inputPrice">
                                        </div>
                                        <div class="col-md-6">
                                            <label for="inputCompareatprice" class="form-label requierd">شماره
                                                تلفن</label>
                                            <input type="tel" class="form-control"  value="{{ $influ->phone }}"  name="phone" id="inputCompareatprice">
                                        </div>
                                        <div class="col-md-6">
                                            <label for="inputCostPerPrice"
                                                   class="form-label requierd">یوزرنیم</label>
                                            <input type="text" name="username" class="form-control"  value="{{ $influ->username }}"  id="inputCostPerPrice">
                                        </div>
                                        <div class="col-md-6">
                                            <label for="inputStarPoints" class="form-label requierd">ایمیل</label>
                                            <input type="email" name="email"  value="{{ $influ->email }}"  class="form-control" id="inputStarPoints">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">آدرس سایت</label>
                                            <input type="url" name="website"  value="{{ $influ->website }}"  class="form-control">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">آیدی تلگرام</label>
                                            <input type="text" name="telegram_id"  value="{{ $influ->telegram_id }}"  class="form-control">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label requierd">آیدی اینستاگرام</label>
                                            <input type="text" name="insta_id" class="form-control"  value="{{ $influ->insta_id }}" >
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">فیسبوک</label>
                                            <input type="text" name="fb_id" class="form-control"  value="{{ $influ->fb_id }}" >
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">توییت</label>

                                            <input type="text" name="twitter_id"  value="{{ $influ->twitter_id }}"  class="form-control">
                                        </div>
                                        <div class="col-md-6">
                                            <div class="col-md-6">
                                                <label class="form-label requierd">محل سکونت</label>
                                                <select name="city" class="form-select" id="">
                                                    <option value="" {{ $influ->city ? '' : 'selected'}} disabled> انتخاب کنید </option>
                                                    @foreach(\App\Models\Map::all() as $map)
                                                        <option value="{{ $map->en }}" {{($influ->city == $map->en) ? 'selected' : '' }}> {{ $map->fn }} </option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
{{--                                        <div class="col-12">--}}
{{--                                            <div class="form-check">--}}
{{--                                                <label class="form-check-label" for="flexCheckDefault">--}}
{{--                                                    آیا اکانت فعال شده است؟--}}
{{--                                                </label>--}}
{{--                                                <input class="form-check-input" type="checkbox" value=""--}}
{{--                                                       id="flexCheckDefault">--}}

{{--                                            </div>--}}
{{--                                        </div>--}}

                                        <h6 class="mb-0 mt-5 requierd">درباره اینفلوئنسر</h6>
                                        <hr>
                                        <div class="col-12 mb-3">

                                            <textarea name="about" id="editor">{{ $influ->about }}</textarea>

                                        </div>

                                        <hr>

                                        <div class="col-md-6 mb-md-3">
                                            <label for="inputProductType" class="form-label requierd">حوضه فعالیت
                                                اینفلوئنسر</label>
                                            <select class="form-select" name="type" id="inputProductType">
                                                <option></option>
                                                <option value="youtube" {{ ($influ->type == 'youtube') ? 'selected' : '' }}>یوتیوب</option>
                                                <option value="instagram" {{ ($influ->type == 'instagram') ? 'selected' : '' }}>اینستاگرام</option>
                                            </select>
                                        </div>

                                        <div class="col-md-6 mb-md-3">
                                            <label for="inputProductType" class="form-label requierd">دسته بندی
                                                اینفلوئنسر</label>
                                            <select class="form-select" name="kind" id="inputProductType">
                                                <option></option>
                                                <option value="mega" {{ ($influ->kind == 'mega') ? 'selected' : '' }}>مگا</option>
                                                <option value="macro" {{ ($influ->kind == 'macro') ? 'selected' : '' }}>ماکرو</option>
                                                <option value="mid" {{ ($influ->kind == 'mid') ? 'selected' : '' }}>میدل</option>
                                                <option value="micro" {{ ($influ->kind == 'micro') ? 'selected' : '' }}>میکرو</option>
                                                <option value="nano" {{ ($influ->kind == 'nano') ? 'selected' : '' }}>نانو</option>
                                            </select>
                                        </div>

                                        <hr>

                                        <div class="col-12">
                                            <p><b>
                                                    دسته بندی اینستاگرام:
                                            </b></p>
                                            @foreach(\App\Models\Category::where('type', 'instagram')->get()->toArray() as $key => $category)
                                            <div class="form-check form-check-inline">
                                                    <input class="form-check-input" name="{{ $category['id'] }}"
                                                           type="checkbox" id="inlineCheckbox{{ $category['id'] }}"
                                                           value="{{ $category['id'] }}"
                                                            {{ (\App\Models\Influencer::find($influ->id)->category()->where('category_id', $category['id'])->first())
                                                            ? 'checked'
                                                            : ''
                                                             }}
                                                        >
                                                    <label class="form-check-label" for="inlineCheckbox{{ $category['id'] }}">{{ $category['name'] }}</label>
                                                </div>
                                            @endforeach
                                        </div>

                                        <hr>

                                        <div class="col-12">
                                            <p><b>
                                                    دسته بندی یوتیوب:
                                            </b></p>
                                            @foreach(\App\Models\Category::where('type', 'youtube')->get()->toArray() as $key => $category)
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" name="{{ $category['id'] }}"
                                                           type="checkbox" id="inlineCheckbox{{ $category['id'] }}"
                                                           value="{{ $category['id'] }}"
                                                            {{ (\App\Models\Influencer::find($influ->id)->category()->where('category_id', $category['id'])->first())
                                                            ? 'checked'
                                                            : ''
                                                             }}
                                                    >
                                                    <label class="form-check-label" for="inlineCheckbox{{ $category['id'] }}">{{ $category['name'] }}</label>
                                                </div>
                                            @endforeach
                                        </div>

                                        <hr>
                                        <div class="col-12">
                                            <div class="d-flex  justify-content-sm-start justify-content-center align-items-center flex-wrap">
                                                @foreach($influ->posts as $post)
                                                    <div class="position-relative uploaded-img-vid-area ">
                                                        <a href="{{ url()->route('delete_influ_post', ['id' => $post->id]) }}" class="link-danger fs-5 position-absolute"><i class="bi bi-x-circle-fill"></i></a>
                                                        @php($ext = explode('.', $post->file_path))
                                                        @if(in_array(end($ext), ['png', 'jpeg', 'jpg']))
                                                            <img src="{{ \Illuminate\Support\Facades\Storage::url($post->file_path) }}" height="100" width="100" alt="">
                                                        @else
                                                            <video width="320" height="240" controls>
                                                                <source src="{{ url(\Illuminate\Support\Facades\Storage::url($post->file_path)) }}">
                                                                شما قابلیت دیدن این صفحه را ندارید.
                                                            </video>
                                                        @endif
                                                    </div>
                                                @endforeach
                                            </div>
                                                <br>
                                            <label for=""> آپلود تصویر پست : </label>
                                            <input type="file" name="post">
                                        </div>

                                        <hr>

                                        <div class="col-md-3">
                                            <label class="form-label">تعداد بازدید</label>
                                            <input type="text" name="seen" value="{{ $influ->seen }}"
                                                   class="form-control">
                                        </div>
                                        <div class="col-md-3">
                                            <label class="form-label">تعداد رای دهندگان</label>
                                            <input type="text" name="scores" value="{{ $influ->scores }}"
                                                   class="form-control">
                                        </div>
                                        <div class="col-md-3">
                                            <label class="form-label">میانگین امتیاز</label>
                                            <input type="text" name="rate" value="{{ $influ->rate }}"
                                                   class="form-control">
                                        </div>



                                        <hr>
                                        <div class="col-md-3">
                                            <label class="form-label">هشتگ و تیکه کلام</label>
                                            <br>
                                            <small class="small">کلمات با # از هم جدا شوند.</small>
                                            <br>
                                            <small class="small">بیشتر از ۴ مورد نوشته نشوند.</small>
                                            <input type="text" name="hashtag" value="{{ $influ->hashtag }}"
                                                   class="form-control">
                                        </div>

                                        <hr>

                                        <div class=" d-flex flex-row-reverse">
                                            <button type="submit" class="btn btn-primary">ذخیره اطلاعات</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--end row-->
                    </div>
                    </form>
                </div>
            </div>

        </div>
    </div>

@endsection