@extends('admin.layouts.master')

@section('title', 'لیست اینفلوئنسر ها')

@section('content')

    <div class="page-wrapper">
        <div class="page-content">
            <div class="row">
                <div class="col-12">
                    <h5 class="card-title">لیست اینفلوئنسر ها</h5>
                    <hr>
                </div>
            </div>
            @if(\Illuminate\Support\Facades\Session::has('deleted'))
                <div class="alert alert-danger d-flex align-items-center" role="alert">
                    <svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Danger:"><use xlink:href="#exclamation-triangle-fill"/></svg>
                    <div>
                        با موفقیت حذف شد.
                    </div>
                </div>
            @endif
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="row align-items-center">
                                <div class="col-sm-1 col-2">
                                    <button type="button" class="btn btn-outline-primary"><i class="bx bx-filter-alt me-0-fill"></i>
                                    </button>
                                </div>
                                <div class="col-lg-3 offset-lg-8 col-md-5 offset-md-6 col-sm-7 offset-sm-4 col-10">
                                    <form action="#" class="d-flex">
                                        <div class="input-group">
                                            <input type="text" class="form-control" placeholder="جستجو">
                                            <button class="btn search-button" type="submit"><i class="bx bx-search-fill"></i>
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row row-cols-1 row-cols-lg-2 row-cols-xl-3">

                @foreach($influss as $influs)

                <div class="col">
                    <div class="card radius-10">
                        <div class="card-body">
                            <div class="d-flex align-items-center">
                                <a href="{{ url()->route('delete.influ', ['id' => $influs['id']]) }}" class="link-secondary fs-4 me-2"><i class="bi bi-x"></i></a>
                                <div class="flex-grow-1 d-flex align-items-center">
                                    <a class="link-secondary fs-6 mt-1" href="{{ url()->route('admin.influencer.info', ['id' => $influs['id']]) }}">
                                        <i class="bi bi-pen-fill"></i>
                                    </a>
                                </div>
                                <div class="d-flex flex-column justify-content-start me-4">
                                    <h5 class="font-weight-bold mb-0 "> {{ $influs['f_name'] }} </h5>

                                </div>
                                <div class="widgets-icons bg-gradient-cosmic text-white overflow-hidden">
                                    @if(!empty($influs['photo']) && ($influs['photo']) != 'profiles/')
                                        <img src="{{ \Illuminate\Support\Facades\Storage::url($influs['photo']) }}" alt="">
                                    @else
                                        <i class="bx bx-user-fill"></i>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                @endforeach

            </div>
        </div>
    </div>

@endsection