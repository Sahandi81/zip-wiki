@extends('admin.layouts.master')

@section('title', 'نظرات عادی')

@section('content')

    <div class="page-wrapper" xmlns="http://www.w3.org/1999/html">
        @if(\Illuminate\Support\Facades\Session::has('delete'))
            <div class="alert alert-danger d-flex align-items-center" role="alert">
                <svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Danger:"><use xlink:href="#exclamation-triangle-fill"/></svg>
                <div>
                    با موفقیت حذف شد.
                </div>
            </div>
        @endif
        @if(\Illuminate\Support\Facades\Session::has('verify'))
            <div class="alert alert-success d-flex align-items-center" role="alert">
                <svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Danger:"><use xlink:href="#exclamation-triangle-fill"/></svg>
                <div>
                    با موفقیت تایید شد.
                </div>
            </div>
        @endif
        <div class="page-content">
            <div class="row">
                <div class="col-12">
                    <h5 class="card-title">تایید نظرات کاربران عادی</h5>
                    <hr>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="d-flex flex-sm-row flex-column-reverse justify-content-between align-items-sm-center">
                                <div class="d-flex mt-sm-0 mt-3">
                                    <button type="button" class="btn me-1 btn-outline-primary"><i class="bx bx-filter-alt me-0-fill"></i>
                                    </button>
                                </div>
                                <div>
                                    <form action="#" class="d-flex">
                                        <div class="input-group">
                                            <input type="text" class="form-control" placeholder="جستجو">
                                            <button class="btn search-button" type="submit"><i class="bx bx-search-fill"></i>
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row row-cols-1 row-cols-lg-2 row-cols-xl-3">

                @foreach($normalComments->toArray() as $normalComment)
                    <div class="col">
                        <div class="card radius-10">
                            <div class="card-body">
                                <div class="d-flex align-items-center">
                                    <div class="flex-grow-1 d-flex align-items-center">
                                        <a class="link-secondary fs-6 mt-1" data-bs-toggle="collapse"
                                           href="#userComment{{ $normalComment['id'] }}" role="button" aria-expanded="false"
                                           aria-controls="userComment{{ $normalComment['id'] }}">
                                            <i class="bi bi-caret-down-fill"></i>
                                        </a>
                                        <small class="p-1 text-success">
                                        @if($normalComment['verified_at'])
                                            {{ 'تایید شده' }}
                                        @endif
                                        </small>
                                    </div>
                                    <h5 class="font-weight-bold mb-0 me-4">{{ $normalComment['user']['name'] ?? 'ناشناس' }} </h5>
                                    <div class="widgets-icons bg-gradient-cosmic text-white">
                                        <i class="bx bx-user-fill"></i>
                                    </div>

                                </div>
                            </div>
                            <div class="collapse" id="userComment{{ $normalComment['id'] }}">
                                <div class="card-body">

                                   {{ $normalComment['comment'] }}<br>
                                    <hr>
                                    نظر کلی : {{ $normalComment['score'] }}
                                </div>
                                <div class="accordion-body">
                                    <a href="{{ url()->route('influencers.single.page', ['id' =>  $normalComment['influencer']['id'] ?? 0]) }}" class="text-decoration-underline link-primary">از صفحه {{ $normalComment['influencer']['f_name'] ?? 'حذف شده' }}</a>
                                </div>
                                <div class="d-flex align-items-center justify-content-end mb-2">
                                    <a href="{{ url()->route('admin.verify.normal.comment', ['id' => $normalComment['id']]) }}" class="link-success fs-5 me-2 mt-1"><i
                                                class="bi bi-check-circle-fill"></i></a>
                                    <a href="{{ url()->route('admin.delete.normal.comment', ['id' => $normalComment['id']]) }}" class="link-danger fs-5 mt-1 me-4"><i
                                                class="bi bi-x-circle-fill"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                @endforeach

                </div>
            </div>
        </div>
    </div
    >

@endsection