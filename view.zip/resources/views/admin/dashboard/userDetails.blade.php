@extends('admin.layouts.master')

@section('title', 'ویرایش کاربران')

@section('content')

    <div class="page-wrapper">
        <div class="page-content">

            <!--breadcrumb-->
            <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
                <div class="breadcrumb-title pe-3">کاربران</div>
                <div class="ps-3">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb mb-0 p-0">
                            <li class="breadcrumb-item"><a href="{{ url()->route('admin.users.list') }}">لیست کاربران عادی</a>
                            </li>
                            <li class="breadcrumb-item active" aria-current="page">ویرایش پروفایل کاربر عادی</li>
                        </ol>
                    </nav>
                </div>
            </div>
            <!--end breadcrumb-->

            <div class="card">
                <div class="card-body p-4">
                    <h5 class="card-title">ویرایش پروفایل کاربر عادی</h5>
                    <hr />
                    <div class="form-body mt-4">
                        <form action="" method="POST" enctype="multipart/form-data">
                            @csrf
                        <div class="row">
                            <div class="col-12">
                                <div class="border border-3 p-4 rounded">
                                    <div class="row g-3">
                                        <div class="col-12 d-flex align-items-center">
                                            <a class="users-profile fs-5 " href="#">
                                                <i class="bi bi-pen mt-2-fill"></i>
                                                <input type="file" name="photo">
                                            </a>
                                            @if(!empty($user->photo) && ($user->photo) != 'profiles/')
                                            <img src="{{ \Illuminate\Support\Facades\Storage::url($user->photo) }}" height="100" width="100" alt="">
                                            @endif
                                        </div>

                                        <div class="col-md-6">
                                            <label for="inputPrice" class="form-label required">نام و نام خانوادگی</label>
                                            <input type="text" name="fname" class="form-control" id="inputPrice"
                                                   value="{{ $user->fname }}">
                                        </div>
                                        <div class="col-md-6">
                                            <label for="inputCompareatprice" class="form-label required">شماره تلفن</label>
                                            <input type="tel" name="phone" class="form-control" id="inputCompareatprice"
                                                   value="{{ $user->phone }}">
                                        </div>
                                        <div class="col-md-6">
                                            <label for="inputCostPerPrice" class="form-label required">یوزرنیم</label>
                                            <input type="text" class="form-control" name="name" id="inputCostPerPrice"
                                                   value="{{ $user->name }}">
                                        </div>
                                        <div class="col-md-6">
                                            <label for="inputStarPoints" class="form-label required">ایمیل</label>
                                            <input type="email" class="form-control" name="email" id="inputStarPoints"
                                                   value="{{ $user->email }}">
                                        </div>
                                        <div class="col-12">
                                            <div class="form-check">
{{--                                                <label class="form-check-label" for="flexCheckDefault">--}}
{{--                                                    آیا اکانت فعال شده است؟--}}
{{--                                                </label>--}}
{{--                                                <input class="form-check-input" type="checkbox" value=""--}}
{{--                                                       id="flexCheckDefault">--}}

                                            </div>
                                        </div>

                                        <hr>

                                        <div class=" d-flex flex-row-reverse">
                                            <button type="submit" class="btn btn-primary">ذخیره اطلاعات</button>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </form>
                        <!--end row-->
                    </div>
                </div>
            </div>

        </div>
    </div>

@endsection