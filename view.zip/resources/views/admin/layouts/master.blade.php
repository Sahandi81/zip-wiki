@include('admin.layouts.header')

@yield('content')


        </div>
<!-- Bootstrap JS -->
<script src="{{ asset('admin/js/bootstrap.bundle.min.js') }}"></script>
<!--plugins-->
<script src="{{ asset('admin/js/jquery.min.js') }}"></script>
<script src="{{ asset('admin/plugins/simplebar/js/simplebar.min.js') }}"></script>
<script src="{{ asset('admin/plugins/metismenu/js/metisMenu.min.js') }}"></script>
<script src="{{ asset('admin/plugins/perfect-scrollbar/js/perfect-scrollbar.js') }}"></script>
<script src="{{ asset('admin/plugins/vectormap/jquery-jvectormap-2.0.2.min.js') }}"></script>
<script src="{{ asset('admin/plugins/vectormap/jquery-jvectormap-world-mill-en.js') }}"></script>
<script src="{{ asset('admin/plugins/highcharts/js/highcharts.js') }}"></script>
<script src="{{ asset('admin/plugins/highcharts/js/exporting.js') }}"></script>
<script src="{{ asset('admin/plugins/highcharts/js/variable-pie.js') }}"></script>
<script src="{{ asset('admin/plugins/highcharts/js/export-data.js') }}"></script>
<script src="{{ asset('admin/plugins/highcharts/js/accessibility.js') }}"></script>
<script src="{{ asset('admin/plugins/apexcharts-bundle/js/apexcharts.min.js') }}"></script>
{{--<script src="https://cdn.tiny.cloud/1/no-api-key/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>--}}

{{--<script>--}}
{{--    tinymce.init({--}}
{{--        selector: '#mytextarea'--}}
{{--    });--}}
{{--</script>--}}
<script>
    ClassicEditor
        .create( document.querySelector( '#editor' ) )
        .then( editor => {
            console.log( editor );
        } )
        .catch( error => {
            console.error( error );
        } );
</script>
<script>
    new PerfectScrollbar('.dashboard-top-countries');
</script>
<script src="{{ asset('admin/js/index.js') }}"></script>
<!--app JS-->
<script src="{{ asset('admin/js/app.js') }}"></script>
    </body>
</html>
