@extends('layouts.app')

@section('title', 'ثبت نام')

@section('bodyStyle', 'background: #131313;')

@section('content')

    <div class="modal fade" id="donateModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">حمایت از ویکی</h5>
                    <button type="button" class="btn-close" style="margin-left: -.5rem; margin-right: auto;" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                    <form action="{{ route('gateway') }}" method="POST" class="blog-d-comment-form">
        <div class="modal-body">
            <div class="blog-d-form mt-0">
                    <div class="row">
                        <div class="col-12">
                            <label for="flname" class="donate-modal-label">نام و نام خانوادگی *</label>
                            <div class="review-input-group mt-2">
                                <input type="text" name="flname" id="flname" placeholder="نام و نام خانوادگی (الزامی)">
                            </div>
                        </div>
                        <div class="col-12">
                            <label for="number" class="mt-4 donate-modal-label">شماره همراه *</label>
                            <div class="review-input-group mt-2">
                                <input type="tel" name="number" id="number" placeholder="شماره تماس (الزامی)">
                            </div>
                        </div>
                        <div class="col-12">
                            <label for="amountMoney" class="mt-4 donate-modal-label">مبلغ *</label>
                            <div class="review-input-group mt-2">
                                <select name="amountMoney" id="amountMoney" placeholder="مبلغ (الزامی)">
                                    <option value="1">مبلغ را انتخاب کنید</option>
                                    <option value="500000">50 هزار تومان</option>
                                    <option value="1500000">150 هزار تومان</option>
                                    <option value="2500000">250 هزار تومان</option>
                                    <option value="5000000">500 هزار تومان</option>
                                    <option value="10000000">۱ میلیون تومان</option>
                                </select>
                            </div>
                        </div>
                    </div>
            </div>

        </div>
        <div class="modal-footer justify-content-start">
            <button type="submit" class=" primary-btn-l" style="padding: 12px 30px; font-weight: 600; font-size: 16px;">پرداخت</button>
            <button type="button" class="primary-btn-md" data-bs-dismiss="modal" style="padding-right: 30px; padding-left: 30px;">بستن</button>
@csrf        </div>
    </form>

            </div>
        </div>
    </div>

    <div class="register-wrapper">
        <div class="container ">
            @if(\Illuminate\Support\Facades\Session::has('errors'))
                <div class="alert alert-danger d-flex align-items-center" role="alert">
                    <svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Danger:"><use xlink:href="#exclamation-triangle-fill"/></svg>
                    <div>
                        اطلاعات به درستی وارد نشده است.
                    </div>
                </div>
            @endif

            <div class="row mt-100 justify-content-center ">
                <div class="col-xxl-6 col-xl-6 col-lg-8 col-md-10 ">
                    <div class="reg-login-forms">
                        <h4 class="reg-login-title text-center">
                            ثبت نام
                        </h4>


                        <form action="#" class="" method="POST" id="register-form">
                            @csrf
                            <div class="text-input register-email reg-input-group">
                                <div class="icon-area">
                                    <i class="bi bi-person-fill form-icons"></i>
                                </div>
                                <input type="text" id="email" name="name" class="input email-input" placeholder="ایدی اینستاگرام" required="">
                            </div>
                            <div class="relative text-input register-email reg-input-group">
                                <div class="icon-area" style="width: 61px;">
                                    <i class="bi bi-lock form-icons"></i>
                                </div>
                                <input type="password" id="password" name="password" class="input password-input" placeholder="رمز عبور دلخواه" required="">
                                <i class="bi bi-eye showpwd" onclick="showPwd('password', this)"> </i>
                            </div>
                            <div class="text-input register-email reg-input-group">
                                <div class="icon-area">
                                    <i class="bi bi-lock form-icons"></i>
                                </div>
                                <input type="password" id="sure-pass" class="input password-input" placeholder="تایید رمز عبور" required="">
                            </div>
                            <div class="password-recover-group d-flex justify-content-between flex-wrap">
                                <div class="reg-input-group reg-check-input d-flex align-items-center">
                                    <input type="checkbox" name="remember" id="form-check" required>
                                    <label for="form-check">مرا به خاطر بسپار</label>
                                </div>
{{--                                <div class="forgot-password-link">--}}
{{--                                    <a href="#">رمز عبور را فراموش کرده اید؟</a>--}}
{{--                                </div>--}}
                            </div>

                            <div class="reg-input-group reg-submit-input d-flex align-items-center">
                                <input type="submit" id="submite-btn" value="ثبت نام">
                            </div>
                        </form>

                        <!-- Modal -->
                        <div class="modal fade" id="sharayetModal" tabindex="-1" aria-labelledby="sharayetModal" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="sharayetModal">شرایط و خط مشی</h5>
                                        <button type="button" class="btn-close" style="margin-left: -.5rem; margin-right: auto;" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">

                                        <p>لورم ایپسوم یا طرح&zwnj;نما به متنی آزمایشی و بی&zwnj;معنی در صنعت چاپ، صفحه&zwnj;آرایی و
                                            طراحی گرافیک گفته
                                            می&zwnj;شود. طراح گرافیک از این متن به عنوان عنصری از ترکیب بندی برای پر کردن
                                            صفحه و ارایه اولیه
                                            شکل ظاهری و کلی طرح سفارش گرفته شده استفاده می نماید
                                            لورم ایپسوم یا طرح&zwnj;نما به متنی آزمایشی و بی&zwnj;معنی در صنعت چاپ، صفحه&zwnj;آرایی و
                                            طراحی گرافیک گفته
                                            می&zwnj;شود. طراح گرافیک از این متن به عنوان عنصری از ترکیب بندی برای پر کردن
                                            صفحه و ارایه اولیه
                                            شکل ظاهری و کلی طرح سفارش گرفته شده استفاده می نماید
                                        </p>

                                    </div>
                                    <div class="modal-footer justify-content-end">
                                        <button type="button" class="primary-btn-md" data-bs-dismiss="modal" style="padding-right: 30px; padding-left: 30px;">بستن</button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="form-line"></div>

                        <div class="row justify-content-center ">
                            <div class="col-lg-12">
                                <div class="register-switcher text-center">
                                    <a href="#" class="resister-btn active mb-sm-0 mb-4">ثبت نام</a>
                                    <a href="{{url('login')}}" class="login-btn">ورود</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


@endsection