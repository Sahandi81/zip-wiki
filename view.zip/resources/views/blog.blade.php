@extends('layouts.app')

@section('title', 'بلاگ و اخبار')

@section('content')


    <div class="hero-area position-relative" style="padding-bottom: 0;">
        <div>
            <div class="swiper-slide hero-slide-item pb-lg-0 pb-5">
                <div class="container">
                    <div class="row d-flex align-items-center">
                        <div class="col-lg-6 offset-lg-1">
                            <div class="slide-item-content text-lg-end text-center">
                                <h1 class="header-title text-light fw-bold header-texts">WIkIInflu</h1>
                                <h4 class="header-sub-title header-texts">اولین و جامع ترین مرجع<br> اینفلوئنسرهای ایرانی در شبکه های اجتماعی</h4>

                            </div>
                        </div>
                        <div class="col-lg-5 d-flex justify-content-center">
                            <div class="profile-header-image-area d-lg-flex d-none justify-content-lg-end">
                                <img src="{{asset('images/site-image/blog/blog-header-image.svg')}} " alt="profile header image" class="img-fluid profile-header-image figure">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    @if(\Illuminate\Support\Facades\Session::has('likeBlog'))
        <div class="alert alert-success w-25 mx-3" role="alert">
            بلاگ پسندیده شد.
        </div>
    @endif
    @if(\Illuminate\Support\Facades\Session::has('removeLikeBlog'))
        <div class="alert alert-danger w-25 mx-3" role="alert">
            پسندیدن خود را پس گرفتید.
        </div>
    @endif


    <!-- Modal -->
    @include('hemayat')




    <main>
        <nav class="navbar navbar-expand-lg navbar-light d-flex" style="border-bottom: 1px solid rgba(51, 158, 102, 0.34);background-color: #E4FFF1;">

            <style>
                @media (max-width: 2585px){
                    .custom-from-2 {
                        flex-direction: row!important;
                    }
                    .custom-br {
                        display: block !important;
                    }
                }
                @media (max-width: 585px){
                    .custom-from-2 {
                        flex-direction: column!important;
                    }
                }
            </style>

            <div class="py-2 container influ-navbar justify-content-lg-between justify-content-center flex-sm-row flex-column">
                <form class="custom-from-2 d-flex align-items-center mt-lg-0 mt-3 flex-sm-column" style="justify-content: space-between;width: 100% !important;">
                    <div class="mb-lg-0 mb-3 d-flex align-items-center flex-sm-row flex-column">
                        <label class="donate-modal-label ms-2">مرتب سازی :</label>
                        <div class="review-input-group">
                            <select style="height: 45px;" name="sort" id="amountMoney">
                                <option value="{{ 'view' }}">جدید ترین</option>
                                <option value="{{ 'newest' }}">پربازدید ترین</option>
                            </select>
                        </div>
                        <label class="donate-modal-label ms-2 me-4">نوع :</label>
                        <div class="review-input-group">
                            <select style="height: 45px;" name="category" id="amountMoney">
                                <option value=""> همه </option>
                                @foreach(\App\Models\BlogCategory::all() as $blogCategory)
                                    <option value="{{ $blogCategory->id }}" {{ request()->get('category') == $blogCategory->id ? 'selected' : '' }}>{{ $blogCategory->name }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center">
                            <input class="search-input me-2" value="{{ request()->get('q') }}" name="q" type="search" placeholder="جستجو" aria-label="Search">
                            <button style="height: 45px;" type="submit" class="btn btn-light search-button">
                                <i class="bi bi-search"></i>
                            </button>
                    </div>

                    <div class="d-flex justify-content-center align-items-center mx-4 p-3">
                            <h5 class="fw-bold ms-1" style="color: #5e5e5e; font-size: 18px;">{{ count($details) }}</h5>
                            <span class="text-secondary" style="font-size: 14px;width: 8rem;">مطلب موجود می باشد</span>
                        </div>
                </form>
            </div>

        </nav>
        <div class="blog-grid mt-24">
            <div class="container">
                <div class="row">

                    @foreach($details as $blog)
                        <div class="col-lg-3 col-md-6 col-sm-6">
                            <div class="blog-card shadow-sm d-flex flex-sm-column flex-row">
                                <div class="blog-thumb">
                                    @if(!empty($blog->photo) && ($blog->photo) != 'blogs/')
                                        <a href="{{ url()->route('blog.single.page', $blog->id) }}"><img src="{{ \Illuminate\Support\Facades\Storage::url($blog->photo) }}" alt=""></a>
                                    @else
                                        <h4 class="w-100 text-center mt-60"> بدون تصویر </h4>
                                    @endif
                                </div>
                                <div class="blog-content">
                                    <div class="blog-top">
                                        <div class="blog-tags">
                                            <a href="#">{{ $blog->title }}</a>
                                        </div>
                                        <div class="d-flex align-items-center">
                                            <label class="ms-2"> {{ $blog->likes_count }} </label>
                                            <a href="{{ url()->route('like.blog', $blog->id) }}">
                                                @if(\Illuminate\Support\Facades\Auth::id() !== null && in_array($blog->id, \App\Models\User::find(\Illuminate\Support\Facades\Auth::id())->blogLikes()->pluck('blog_id')->toArray() ?? []))
                                                    <i class="bi bi-heart-fill like__icon" onclick="executeLike(this)"></i>
                                                @else
                                                    <i class="bi bi-heart like__icon" onclick="executeLike(this)"></i>
                                                @endif
                                            </a>
                                        </div>
                                    </div>
                                    <h3 class="blog-title"><a href="{{ url()->route('blog.single.page', $blog->id) }}">
                                            {{ $blog->slug }}
                                        </a></h3>
                                    <div class="blog-bottom">
                                        <div class="blog-writer-link">
                                            <a><span> {{ jdate($blog->created_at)->format('d F Y')}} </span></a>
                                            <a class=""><span>{{ $blog->nevisande }}</span></a>
                                        </div>
                                        <div class="d-flex">
                                            <h6>
                                                <span class="ms-2">{{ $blog->seen }}</span>
                                            </h6>
                                            <i class="bi bi-eye pt-0 ms-2 fs-6-fill"></i>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
    </main>

@endsection