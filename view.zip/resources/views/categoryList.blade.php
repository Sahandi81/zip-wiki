@extends('layouts.app')

@section('title', 'دسته بندی ها')

@section('content')


    <div class="hero-area position-relative pt-3"></div>

    @include('hemayat')

<div class="product-area mt-60">
    <div class="container">
        <div class="row justify-content-center mb-5">
            <div class="col-12 d-flex justify-content-center align-items-center">


                <div class="partner-title">
                    <h3 class="h3-title d-flex justify-content-center">
                        <div><i class="bi-instagram insta-logo"></i></div>
                        اینفلوئنسرهای اینستاگرام
                    </h3>
                </div>

            </div>

        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="product-tab-buttons">
                    <ul class="nav nav-pills justify-content-center" id="pills-tab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link {{ (request()->get('kind') == 'mega') ? '' : '' }} " id="pills-nano-tab" data-bs-toggle="pill"
                                    data-bs-target="#pills-nano" type="button" role="tab" aria-controls="pills-nano"
                                    aria-selected="{{ (request()->get('kind') == 'mega') ? 'true' : 'false' }}">Mega  Influ</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link {{ (request()->get('kind') == 'macro') ? '' : '' }}" id="pills-micro-tab" data-bs-toggle="pill"
                                    data-bs-target="#pills-micro" type="button" role="tab"
                                    aria-controls="pills-contact" aria-selected="{{ (request()->get('kind') == 'macro') ? 'true' : 'false' }}">Macro Influ</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link {{ (request()->get('kind') == 'mid') ? '' : '' }}" id="pills-mid-tab" data-bs-toggle="pill"
                                    data-bs-target="#pills-mid" type="button" role="tab"
                                    aria-controls="pills-contact" aria-selected="{{ (request()->get('kind') == 'mid') ? 'true' : 'false' }}">Mid-Tier</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link {{ (request()->get('kind') == 'micro') ? '' : '' }}" id="pills-macro-tab" data-bs-toggle="pill"
                                    data-bs-target="#pills-macro" type="button" role="tab"
                                    aria-controls="pills-profile" aria-selected="{{ (request()->get('kind') == 'micro') ? 'true' : 'false' }}">Micro Influ</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link {{ (request()->get('kind') == 'nano') ? '' : '' }}" id="pills-mega-tab" data-bs-toggle="pill"
                                    data-bs-target="#pills-mega" type="button" role="tab"
                                    aria-controls="pills-contact" aria-selected="{{ (request()->get('kind') == 'nano') ? 'true' : 'false' }}">Nano Influ</button>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="tab-content product-tab" id="pills-tabContent">
                    @php
                    $kind = 'mega';
                    @endphp
                    <div class="tab-pane fade show active" id="pills-nano" role="tabpanel"
                         aria-labelledby="pills-nano-tab">
                        <div class="row gy-5">
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 1]) }}"><img src="{{asset('images/site-image/influ-job-category/Sabk-Zendegi.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 1]) }}" class="link-dark">سبک زندگی</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 2]) }}"><img src="{{asset('images/site-image/influ-job-category/Ashpazi.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 2]) }}" class="link-dark">آشپزی</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 3]) }}"><img src="{{asset('images/site-image/influ-job-category/Roozmaregi.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 3]) }}" class="link-dark">روزمرگی</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 4]) }}"><img src="{{asset('images/site-image/influ-job-category/Tester-food.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 4]) }}" class="link-dark">تستر غذا</a></h5>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 5]) }}"><img src="{{asset('images/site-image/influ-job-category/Arayesh-Zibaii.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 5]) }}" class="link-dark">آرایشی و زیبایی</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 6]) }}"><img src="{{asset('images/site-image/influ-job-category/Swit-home.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 6]) }}" class="link-dark">سوئیت هوم</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 7]) }}"><img src="{{asset('images/site-image/influ-job-category/Madar-dokhtar.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 7]) }}" class="link-dark">مادر و کودک</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 8]) }}"><img src="{{asset('images/site-image/influ-job-category/Gardeshgary.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 8]) }}" class="link-dark">گردشگری</a></h5>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 9]) }}"><img src="{{asset('images/site-image/influ-job-category/Viner.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 9]) }}" class="link-dark">واینر (کمدین مجازی)</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 10]) }}"><img src="{{asset('images/site-image/influ-job-category/Varzeshi.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 10]) }}" class="link-dark">ورزشی</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 11]) }}"><img src="{{asset('images/site-image/influ-job-category/Angizeshi.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 11]) }}" class="link-dark">انگیزشی</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 12]) }}"><img src="{{asset('images/site-image/influ-job-category/Moshaver.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 12]) }}" class="link-dark">مشاور کسب و کار</a></h5>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 1]) }}"><img src="{{asset('images/site-image/influ-job-category/Youtuber.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 1]) }}" class="link-dark">یوتیوبر</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 1]) }}"><img src="{{asset('images/site-image/influ-job-category/Tik-Tok.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 1]) }}" class="link-dark">تیک تاکی</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 1]) }}"><img src="{{asset('images/site-image/influ-job-category/Adab-Moasherat.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 1]) }}" class="link-dark">آداب معاشرت</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 13]) }}"><img src="{{asset('images/site-image/influ-job-category/Graphic.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 13]) }}" class="link-dark">طراح و گرافیست</a></h5>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 14]) }}"><img src="{{asset('images/site-image/influ-job-category/Streamer.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 14]) }}" class="link-dark">استریمر و گیمر</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 15]) }}"><img src="{{asset('images/site-image/influ-job-category/Gooiandegi.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 15]) }}" class="link-dark">گویندگی</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 16]) }}"><img src="{{asset('images/site-image/influ-job-category/Ramzarz.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 16]) }}" class="link-dark">رمزارز</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 17]) }}"><img src="{{asset('images/site-image/influ-job-category/Khabarnegar.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 17]) }}" class="link-dark">خبرنگار</a></h5>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 18]) }}"><img src="{{asset('images/site-image/influ-job-category/Sinama.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 18]) }}" class="link-dark">سینما و تئاتر و تلویزیون</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 19]) }}"><img src="{{asset('images/site-image/influ-job-category/Dakheli.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 19]) }}" class="link-dark">طراح داخلی و معماری</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 20]) }}"><img src="{{asset('images/site-image/influ-job-category/music-history.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 20]) }}" class="link-dark">موسیقی</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 21]) }}"><img src="{{asset('images/site-image/influ-job-category/Ejtemaii.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 21]) }}" class="link-dark">سیاسی اجتماعی</a></h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    @php
                    $kind = 'macro';
                    @endphp
                    <div class="tab-pane fade" id="pills-micro" role="tabpanel"
                         aria-labelledby="pills-micro-tab">
                        <div class="row gy-5">
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 1]) }}"><img src="{{asset('images/site-image/influ-job-category/Sabk-Zendegi.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 1]) }}" class="link-dark">سبک زندگی</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 2]) }}"><img src="{{asset('images/site-image/influ-job-category/Ashpazi.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 2]) }}" class="link-dark">آشپزی</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 3]) }}"><img src="{{asset('images/site-image/influ-job-category/Roozmaregi.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 3]) }}" class="link-dark">روزمرگی</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 4]) }}"><img src="{{asset('images/site-image/influ-job-category/Tester-food.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 4]) }}" class="link-dark">تستر غذا</a></h5>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 5]) }}"><img src="{{asset('images/site-image/influ-job-category/Arayesh-Zibaii.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 5]) }}" class="link-dark">آرایشی و زیبایی</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 6]) }}"><img src="{{asset('images/site-image/influ-job-category/Swit-home.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 6]) }}" class="link-dark">سوئیت هوم</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 7]) }}"><img src="{{asset('images/site-image/influ-job-category/Madar-dokhtar.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 7]) }}" class="link-dark">مادر و کودک</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 8]) }}"><img src="{{asset('images/site-image/influ-job-category/Gardeshgary.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 8]) }}" class="link-dark">گردشگری</a></h5>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 9]) }}"><img src="{{asset('images/site-image/influ-job-category/Viner.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 9]) }}" class="link-dark">واینر (کمدین مجازی)</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 10]) }}"><img src="{{asset('images/site-image/influ-job-category/Varzeshi.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 10]) }}" class="link-dark">ورزشی</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 11]) }}"><img src="{{asset('images/site-image/influ-job-category/Angizeshi.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 11]) }}" class="link-dark">انگیزشی</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 12]) }}"><img src="{{asset('images/site-image/influ-job-category/Moshaver.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 12]) }}" class="link-dark">مشاور کسب و کار</a></h5>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 1]) }}"><img src="{{asset('images/site-image/influ-job-category/Youtuber.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 1]) }}" class="link-dark">یوتیوبر</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 1]) }}"><img src="{{asset('images/site-image/influ-job-category/Tik-Tok.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 1]) }}" class="link-dark">تیک تاکی</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 1]) }}"><img src="{{asset('images/site-image/influ-job-category/Adab-Moasherat.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 1]) }}" class="link-dark">آداب معاشرت</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 13]) }}"><img src="{{asset('images/site-image/influ-job-category/Graphic.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 13]) }}" class="link-dark">طراح و گرافیست</a></h5>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 14]) }}"><img src="{{asset('images/site-image/influ-job-category/Streamer.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 14]) }}" class="link-dark">استریمر و گیمر</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 15]) }}"><img src="{{asset('images/site-image/influ-job-category/Gooiandegi.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 15]) }}" class="link-dark">گویندگی</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 16]) }}"><img src="{{asset('images/site-image/influ-job-category/Ramzarz.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 16]) }}" class="link-dark">رمزارز</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 17]) }}"><img src="{{asset('images/site-image/influ-job-category/Khabarnegar.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 17]) }}" class="link-dark">خبرنگار</a></h5>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 18]) }}"><img src="{{asset('images/site-image/influ-job-category/Sinama.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 18]) }}" class="link-dark">سینما و تئاتر و تلویزیون</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 19]) }}"><img src="{{asset('images/site-image/influ-job-category/Dakheli.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 19]) }}" class="link-dark">طراح داخلی و معماری</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 1]) }}"><img src="{{asset('images/site-image/influ-job-category/music-history.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 20]) }}" class="link-dark">موسیقی</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 21]) }}"><img src="{{asset('images/site-image/influ-job-category/Ejtemaii.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 21]) }}" class="link-dark">سیاسی اجتماعی</a></h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    @php
                    $kind = 'mid';
                    @endphp
                    <div class="tab-pane fade" id="pills-mid" role="tabpanel"
                         aria-labelledby="pills-mid-tab">
                        <div class="row gy-5">
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 1]) }}"><img src="{{asset('images/site-image/influ-job-category/Sabk-Zendegi.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 1]) }}" class="link-dark">سبک زندگی</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 2]) }}"><img src="{{asset('images/site-image/influ-job-category/Ashpazi.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 2]) }}" class="link-dark">آشپزی</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 3]) }}"><img src="{{asset('images/site-image/influ-job-category/Roozmaregi.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 3]) }}" class="link-dark">روزمرگی</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 4]) }}"><img src="{{asset('images/site-image/influ-job-category/Tester-food.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 4]) }}" class="link-dark">تستر غذا</a></h5>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 5]) }}"><img src="{{asset('images/site-image/influ-job-category/Arayesh-Zibaii.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 5]) }}" class="link-dark">آرایشی و زیبایی</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 6]) }}"><img src="{{asset('images/site-image/influ-job-category/Swit-home.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 6]) }}" class="link-dark">سوئیت هوم</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 7]) }}"><img src="{{asset('images/site-image/influ-job-category/Madar-dokhtar.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 7]) }}" class="link-dark">مادر و کودک</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 8]) }}"><img src="{{asset('images/site-image/influ-job-category/Gardeshgary.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 8]) }}" class="link-dark">گردشگری</a></h5>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 9]) }}"><img src="{{asset('images/site-image/influ-job-category/Viner.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 9]) }}" class="link-dark">واینر (کمدین مجازی)</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 10]) }}"><img src="{{asset('images/site-image/influ-job-category/Varzeshi.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 10]) }}" class="link-dark">ورزشی</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 11]) }}"><img src="{{asset('images/site-image/influ-job-category/Angizeshi.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 11]) }}" class="link-dark">انگیزشی</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 12]) }}"><img src="{{asset('images/site-image/influ-job-category/Moshaver.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 12]) }}" class="link-dark">مشاور کسب و کار</a></h5>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 1]) }}"><img src="{{asset('images/site-image/influ-job-category/Youtuber.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 1]) }}" class="link-dark">یوتیوبر</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 1]) }}"><img src="{{asset('images/site-image/influ-job-category/Tik-Tok.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 1]) }}" class="link-dark">تیک تاکی</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 1]) }}"><img src="{{asset('images/site-image/influ-job-category/Adab-Moasherat.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 1]) }}" class="link-dark">آداب معاشرت</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 13]) }}"><img src="{{asset('images/site-image/influ-job-category/Graphic.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 13]) }}" class="link-dark">طراح و گرافیست</a></h5>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 14]) }}"><img src="{{asset('images/site-image/influ-job-category/Streamer.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 14]) }}" class="link-dark">استریمر و گیمر</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 15]) }}"><img src="{{asset('images/site-image/influ-job-category/Gooiandegi.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 15]) }}" class="link-dark">گویندگی</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 16]) }}"><img src="{{asset('images/site-image/influ-job-category/Ramzarz.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 16]) }}" class="link-dark">رمزارز</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 17]) }}"><img src="{{asset('images/site-image/influ-job-category/Khabarnegar.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 17]) }}" class="link-dark">خبرنگار</a></h5>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 18]) }}"><img src="{{asset('images/site-image/influ-job-category/Sinama.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 18]) }}" class="link-dark">سینما و تئاتر و تلویزیون</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 19]) }}"><img src="{{asset('images/site-image/influ-job-category/Dakheli.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 19]) }}" class="link-dark">طراح داخلی و معماری</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 1]) }}"><img src="{{asset('images/site-image/influ-job-category/music-history.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 20]) }}" class="link-dark">موسیقی</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 21]) }}"><img src="{{asset('images/site-image/influ-job-category/Ejtemaii.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 21]) }}" class="link-dark">سیاسی اجتماعی</a></h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    @php
                    $kind = 'micro';
                    @endphp
                    <div class="tab-pane fade" id="pills-macro" role="tabpanel"
                         aria-labelledby="pills-macro-tab">
                        <div class="row gy-5">
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 1]) }}"><img src="{{asset('images/site-image/influ-job-category/Sabk-Zendegi.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 1]) }}" class="link-dark">سبک زندگی</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 2]) }}"><img src="{{asset('images/site-image/influ-job-category/Ashpazi.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 2]) }}" class="link-dark">آشپزی</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 3]) }}"><img src="{{asset('images/site-image/influ-job-category/Roozmaregi.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 3]) }}" class="link-dark">روزمرگی</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 4]) }}"><img src="{{asset('images/site-image/influ-job-category/Tester-food.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 4]) }}" class="link-dark">تستر غذا</a></h5>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 5]) }}"><img src="{{asset('images/site-image/influ-job-category/Arayesh-Zibaii.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 5]) }}" class="link-dark">آرایشی و زیبایی</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 6]) }}"><img src="{{asset('images/site-image/influ-job-category/Swit-home.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 6]) }}" class="link-dark">سوئیت هوم</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 7]) }}"><img src="{{asset('images/site-image/influ-job-category/Madar-dokhtar.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 7]) }}" class="link-dark">مادر و کودک</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 8]) }}"><img src="{{ asset('images/site-image/influ-job-category/Gardeshgary.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 8]) }}" class="link-dark">گردشگری</a></h5>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 9]) }}"><img src="{{asset('images/site-image/influ-job-category/Viner.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 9]) }}" class="link-dark">واینر (کمدین مجازی)</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 10]) }}"><img src="{{asset('images/site-image/influ-job-category/Varzeshi.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 10]) }}" class="link-dark">ورزشی</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 11]) }}"><img src="{{asset('images/site-image/influ-job-category/Angizeshi.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 11]) }}" class="link-dark">انگیزشی</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 12]) }}"><img src="{{asset('images/site-image/influ-job-category/Moshaver.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 12]) }}" class="link-dark">مشاور کسب و کار</a></h5>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 1]) }}"><img src="{{asset('images/site-image/influ-job-category/Youtuber.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 1]) }}" class="link-dark">یوتیوبر</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 1]) }}"><img src="{{asset('images/site-image/influ-job-category/Tik-Tok.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 1]) }}" class="link-dark">تیک تاکی</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 1]) }}"><img src="{{asset('images/site-image/influ-job-category/Adab-Moasherat.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 1]) }}" class="link-dark">آداب معاشرت</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 13]) }}"><img src="{{asset('images/site-image/influ-job-category/Graphic.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 13]) }}" class="link-dark">طراح و گرافیست</a></h5>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 14]) }}"><img src="{{asset('images/site-image/influ-job-category/Streamer.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 14]) }}" class="link-dark">استریمر و گیمر</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 15]) }}"><img src="{{asset('images/site-image/influ-job-category/Gooiandegi.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 15]) }}" class="link-dark">گویندگی</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 16]) }}"><img src="{{asset('images/site-image/influ-job-category/Ramzarz.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 16]) }}" class="link-dark">رمزارز</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 17]) }}"><img src="{{asset('images/site-image/influ-job-category/Khabarnegar.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 17]) }}" class="link-dark">خبرنگار</a></h5>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 18]) }}"><img src="{{asset('images/site-image/influ-job-category/Sinama.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 18]) }}" class="link-dark">سینما و تئاتر و تلویزیون</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 19]) }}"><img src="{{asset('images/site-image/influ-job-category/Dakheli.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 19]) }}" class="link-dark">طراح داخلی و معماری</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 1]) }}"><img src="{{asset('images/site-image/influ-job-category/music-history.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 20]) }}" class="link-dark">موسیقی</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 21]) }}"><img src="{{asset('images/site-image/influ-job-category/Ejtemaii.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 21]) }}" class="link-dark">سیاسی اجتماعی</a></h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    @php
                    $kind = 'nano';
                    @endphp
                    <div class="tab-pane fade" id="pills-mega" role="tabpanel"
                         aria-labelledby="pills-mega-tab">
                        <div class="row gy-5">
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 1]) }}"><img src="{{asset('images/site-image/influ-job-category/Sabk-Zendegi.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 1]) }}" class="link-dark">سبک زندگی</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 2]) }}"><img src="{{asset('images/site-image/influ-job-category/Ashpazi.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 2]) }}" class="link-dark">آشپزی</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 3]) }}"><img src="{{asset('images/site-image/influ-job-category/Roozmaregi.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 3]) }}" class="link-dark">روزمرگی</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 4]) }}"><img src="{{asset('images/site-image/influ-job-category/Tester-food.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 4]) }}" class="link-dark">تستر غذا</a></h5>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 5]) }}"><img src="{{asset('images/site-image/influ-job-category/Arayesh-Zibaii.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 5]) }}" class="link-dark">آرایشی و زیبایی</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 6]) }}"><img src="{{asset('images/site-image/influ-job-category/Swit-home.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 6]) }}" class="link-dark">سوئیت هوم</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 7]) }}"><img src="{{asset('images/site-image/influ-job-category/Madar-dokhtar.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 7]) }}" class="link-dark">مادر و کودک</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 8]) }}"><img src="{{asset('images/site-image/influ-job-category/Gardeshgary.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 8]) }}" class="link-dark">گردشگری</a></h5>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 9]) }}"><img src="{{asset('images/site-image/influ-job-category/Viner.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 9]) }}" class="link-dark">واینر (کمدین مجازی)</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 10]) }}"><img src="{{asset('images/site-image/influ-job-category/Varzeshi.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 10]) }}" class="link-dark">ورزشی</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 11]) }}"><img src="{{asset('images/site-image/influ-job-category/Angizeshi.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 11]) }}" class="link-dark">انگیزشی</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 12]) }}"><img src="{{asset('images/site-image/influ-job-category/Moshaver.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 12]) }}" class="link-dark">مشاور کسب و کار</a></h5>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 1]) }}"><img src="{{asset('images/site-image/influ-job-category/Youtuber.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 1]) }}" class="link-dark">یوتیوبر</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 1]) }}"><img src="{{asset('images/site-image/influ-job-category/Tik-Tok.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 1]) }}" class="link-dark">تیک تاکی</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 1]) }}"><img src="{{asset('images/site-image/influ-job-category/Adab-Moasherat.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 1]) }}" class="link-dark">آداب معاشرت</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 13]) }}"><img src="{{asset('images/site-image/influ-job-category/Graphic.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 13]) }}" class="link-dark">طراح و گرافیست</a></h5>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 14]) }}"><img src="{{asset('images/site-image/influ-job-category/Streamer.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 14]) }}" class="link-dark">استریمر و گیمر</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 15]) }}"><img src="{{asset('images/site-image/influ-job-category/Gooiandegi.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 15]) }}" class="link-dark">گویندگی</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 16]) }}"><img src="{{asset('images/site-image/influ-job-category/Ramzarz.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 16]) }}" class="link-dark">رمزارز</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 17]) }}"><img src="{{asset('images/site-image/influ-job-category/Khabarnegar.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 17]) }}" class="link-dark">خبرنگار</a></h5>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 18]) }}"><img src="{{asset('images/site-image/influ-job-category/Sinama.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 18]) }}" class="link-dark">سینما و تئاتر و تلویزیون</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 19]) }}"><img src="{{asset('images/site-image/influ-job-category/Dakheli.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 19]) }}" class="link-dark">طراح داخلی و معماری</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 1]) }}"><img src="{{asset("images/site-image/influ-job-category/music-history.svg")}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 20]) }}" class="link-dark">موسیقی</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 px-4">

                                <div class="influ-card mt-0 shadow-lg">
                                    <div class="influ-job-category-thumb">
                                        <a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 21]) }}"><img src="{{asset('images/site-image/influ-job-category/Ejtemaii.svg')}}" alt=""></a>

                                    </div>
                                    <div class="card-content d-flex justify-content-center">
                                        <h5><a href="{{ url()->route('influencers.list', ['type' => 'instagram', 'kind' => $kind, 'category' => 21]) }}" class="link-dark">سیاسی اجتماعی</a></h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection