<div class="blog-area-start mt-90 mb-5">
    <div class="container">
        <div class="row">

        <div class="d-flex justify-content-between align-items-center pb-4 flex-sm-row flex-column">
            <div class="section-title d-flex mb-sm-0 mb-3">

                <div class="d-flex align-items-center text-white justify-content-center text-center">
                    <h2 class="ms-2 box-title text-white"> بلاگ و اخبار </h2>
                </div>
            </div>
            <div class="show-more d-flex justify-content-between align-items-center text-center">
                <a href="#" class="show-more-button d-flex text-white text-center">
                    <a href="{{ url('blog') }}"><h6 class="ms-1 text-black" style="color: white !important;">مشاهده بیشتر</h6></a>
                    <i class="bi bi-caret-left-fill text-white-fill"></i>
                </a>
            </div>
        </div>

            @foreach(\App\Models\Blog::withCount('likes')->where('influencer_id', null)->orWhere('influencer_id', 0)->get()->sortDesc()->take(4) as $blog)
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="blog-card shadow-sm d-flex flex-sm-column flex-row">
                        <div class="blog-thumb">
                            @if(!empty($blog->photo) && ($blog->photo) != 'blogs/')
                                <a href="{{ url()->route('blog.single.page', $blog->id) }}"><img src="{{ \Illuminate\Support\Facades\Storage::url($blog->photo) }}" alt=""></a>
                            @else
                                <h4 class="w-100 text-center mt-60"> بدون تصویر </h4>
                            @endif
                        </div>
                        <div class="blog-content">
                            <div class="blog-top">
                                <div class="blog-tags">
                                    <a href="#">{{ $blog->title }}</a>
                                </div>
                                <div class="d-flex align-items-center">
                                    <label class="ms-2"> {{ $blog->likes_count }} </label>
                                    <a href="{{ url()->route('like.blog', $blog->id) }}">
                                        @if(\Illuminate\Support\Facades\Auth::id() !== null && in_array($blog->id, \App\Models\User::find(\Illuminate\Support\Facades\Auth::id())->blogLikes()->pluck('blog_id')->toArray() ?? []))
                                            <i class="bi bi-heart-fill like__icon" onclick="executeLike(this)"></i>
                                        @else
                                            <i class="bi bi-heart like__icon" onclick="executeLike(this)"></i>
                                        @endif
                                    </a>
                                </div>
                            </div>
                            <h3 class="blog-title"><a href="{{ url()->route('blog.single.page', $blog->id) }}">
                                    {{ $blog->slug }}
                                </a></h3>
                            <div class="blog-bottom">
                                <div class="blog-writer-link">
                                    <a><span> {{ jdate(strtotime($blog->created_at))->format('d F Y') }} </span></a>
                                    <a class=""><span>{{ $blog->nevisande }}</span></a>
                                </div>
                                <div class="d-flex align-items-center">
                                    <label class="ms-2">{{ $blog->seen }}</label>
                                    <i class="bi bi-eye-fill see-icon-fill"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach

        </div>
    </div>
</div>
