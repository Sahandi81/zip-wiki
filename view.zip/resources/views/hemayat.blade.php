<div class="modal fade" id="donateModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">حمایت از ویکی</h5>
                <button type="button" class="btn-close" style="margin-left: -.5rem; margin-right: auto;" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="{{ route('gateway') }}" method="POST" class="blog-d-comment-form">
                <div class="modal-body">
                    <div class="blog-d-form mt-0">
                        <div class="row">
                            <div class="col-12">
                                <label for="flname" class="donate-modal-label">نام و نام خانوادگی *</label>
                                <div class="review-input-group mt-2">
                                    <input type="text" name="flname" id="flname" placeholder="نام و نام خانوادگی (الزامی)">
                                </div>
                            </div>
                            <div class="col-12">
                                <label for="number" class="mt-4 donate-modal-label">شماره همراه *</label>
                                <div class="review-input-group mt-2">
                                    <input type="tel" name="number" id="number" placeholder="شماره تماس (الزامی)">
                                </div>
                            </div>
                            <div class="col-12">
                                <label for="amountMoney" class="mt-4 donate-modal-label">مبلغ *</label>
                                <div class="review-input-group mt-2">
                                    <select name="amountMoney" id="amountMoney" placeholder="مبلغ (الزامی)">
                                        <option value="1">مبلغ را انتخاب کنید</option>
                                        <option value="500000">50 هزار تومان</option>
                                        <option value="1500000">150 هزار تومان</option>
                                        <option value="2500000">250 هزار تومان</option>
                                        <option value="5000000">500 هزار تومان</option>
                                        <option value="10000000">۱ میلیون تومان</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                @csrf
                <div class="modal-footer justify-content-start">
                    <button type="submit" class=" primary-btn-l" style="padding: 12px 30px; font-weight: 600; font-size: 16px;">پرداخت</button>
                    <button type="button" class="primary-btn-md" data-bs-dismiss="modal" style="padding-right: 30px; padding-left: 30px;">بستن</button>
                </div>
            </form>

        </div>
    </div>
</div>
