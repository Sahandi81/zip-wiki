@extends('layouts.app')

@section('title', 'صفحه اصلی')

@section('content')

<div class="hero-area position-relative">
	<div>
		<div class="swiper-slide hero-slide-item">
			<div class="container">
				<div class="row d-flex align-items-center">
					<div class="col-lg-6">
						<div class="slide-item-content text-lg-end text-center">
							<h1 class="header-title text-light fw-bold header-texts">WIkIInflu</h1>
							<h4 class="header-sub-title header-texts" style="line-height: 1.9;font-size: 31px;">اولین و جامع ترین مرجع<br> اینفلوئنسرهای ایرانی در شبکه های اجتماعی</h4>
							<br>
							<p class="header-texts">ویکی اینفلو بستری جهت معرفی آنالیز و آموزش اینفلوئنسری و همکاری در زمینه اینفلوئنسرمارکتینگ می باشد.</p>
							<div class="slide-item-btn mb-lg-0 mb-3">
								<a data-bs-toggle="modal" href="#donateModal" class="primary-btn-xl mb-lg-0 mb-5">حمایت از ویکی</a>
							</div>
						</div>
					</div>
					<div class="col-lg-6 d-flex justify-content-center">
						<div class="slide-item-figure d-lg-flex d-none justify-content-lg-end">
							<img src="{{ asset('images/site-image/home/home-header.svg') }}" alt="" class="img-fluid figure">
{{--							<div class="florting-figure">--}}
{{--								<img src="{{ asset('images/hero/florting-figure-1.png') }}" alt="">--}}
{{--							</div>--}}
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

</div>

<!-- Modal -->
@include('hemayat')

<section class="sub-header-bar bg-transparent text-center ">

	<div class="justify-content-center">
		<div class="col-lg-12 d-flex justify-content-center align-items-center">
			<div class="swiper-button-prev d-xl-none d-block" tabindex="0" role="button"
				 aria-label="Previous slide">
				<i class=flaticon-arrow-pointing-to-left-fill"></i>
			</div>

			<!-- <div class="before-line d-lg-block d-none"></div> -->
			<!-- <img src="assets/images/left-line.png" alt="left-line picture" class="dividing-line"> -->

			<div class="partner-title">
				<h3 class="h3-title d-flex justify-content-center">
					<div><i class="bi-instagram insta-logo-fill m-2"></i></div>
					اینفلوئنسرهای اینستاگرام
				</h3>
			</div>
			<!-- <div class="next-line d-lg-block d-none"></div> -->
			<!-- <img src="assets/images/right-line.png" alt="right-line picture" class="dividing-line"> -->

			<div class="swiper-button-next d-xl-none d-block" tabindex="0" role="button" aria-label="Next slide">
				<i class="flaticon-arrow-pointing-to-left-fill"></i>
			</div>
		</div>
	</div>

	<div class="category-area position-relative">
		<div>
			<div class="swiper-container category-slider container d-xl-none d-block">
				<div class="swiper-wrapper">
					<div class="swiper-slide">
						<div class="feature-card influ-feature-card">
							<a href="{{ url()->route('category.list', ['type' => 'instagram', 'kind' => 'mega']) }}">
								<div class="feature-vactor position-absolute">
									<img src="{{asset('images/shapes/feature-line-vactor.png')}}" alt="">
								</div>
								<div class="feature-icon">
									<img src="{{asset('images/site-image/home/mega-img.svg')}}" alt="">
								</div>
								<h5>Mega Influencer</h5>
								<p dir="ltr">+1M</p>
							</a>
						</div>
					</div>
					<div class="swiper-slide">
						<div class="feature-card influ-feature-card">
							<a href="{{ url()->route('category.list', ['type' => 'instagram', 'kind' => 'macro']) }}">
								<div class="feature-vactor position-absolute">
									<img src="{{asset('images/shapes/feature-line-vactor.png')}}" alt="">
								</div>
								<div class="feature-icon">
									<img src="{{asset('images/site-image/home/macro-img.svg')}}" alt="">
								</div>
								<h5>Macro Influencer</h5>
								<p dir="ltr">500 - 1M</p>
							</a>
						</div>
					</div>
					<div class="swiper-slide">
						<div class="feature-card influ-feature-card">
							<a href="{{ url()->route('category.list', ['type' => 'instagram', 'kind' => 'mid']) }}">
								<div class="feature-vactor position-absolute">
									<img src="{{asset('images/shapes/feature-line-vactor.png')}}" alt="">
								</div>
								<div class="feature-icon">
									<img src="{{asset('images/site-image/home/mid-img.svg')}}" alt="">
								</div>
								<h5>Mid - Tier</h5>
								<p dir="ltr">100 - 50K</p>
							</a>
						</div>
					</div>
					<div class="swiper-slide">
						<div class="feature-card influ-feature-card ">
							<a href="{{ url()->route('category.list', ['type' => 'instagram', 'kind' => 'micro']) }}">
								<div class="feature-vactor position-absolute">
									<img src="{{asset('images/shapes/feature-line-vactor.png')}}" alt="">
								</div>
								<div class="feature-icon">
									<img src="{{asset('images/site-image/home/micro-img.svg')}}" alt="">
								</div>
								<h5>Micro Influencer</h5>
								<p dir="ltr">10 - 100K</p>
							</a>
						</div>
					</div>
					<div class="swiper-slide">
						<div class="feature-card influ-feature-card">
							<a href="{{ url()->route('category.list', ['type' => 'instagram', 'kind' => 'nano']) }}">
								<div class="feature-vactor position-absolute">
									<img src="{{asset('images/shapes/feature-line-vactor.png')}}" alt="">
								</div>
								<div class="feature-icon">
									<img src="{{asset('images/site-image/home/nano-img.svg')}}" alt="">
								</div>
								<h5>Nano Influencer</h5>
							</a>
						</div>
					</div>
				</div>
			</div>

			<div class="d-xl-flex justify-content-evenly px-2 d-none">
				<div class="feature-card influ-feature-card" style="width: 19%">
					<a href="{{ url()->route('category.list', ['type' => 'instagram', 'kind' => 'mega']) }}">
						<div class="feature-vactor position-absolute">
							<img src="{{asset('images/shapes/feature-line-vactor.png')}}" alt="">
						</div>
						<div class="feature-icon">
							<img src="{{asset('images/site-image/home/mega-img.svg')}}" alt="">
						</div>
						<h5>Mega Influencer</h5>
					</a>
				</div>
				<div class="feature-card influ-feature-card" style="width: 19%">
					<a href="{{ url()->route('category.list', ['type' => 'instagram', 'kind' => 'macro']) }}">
						<div class="feature-vactor position-absolute">
							<img src="{{asset('images/shapes/feature-line-vactor.png')}}" alt="">
						</div>
						<div class="feature-icon">
							<img src="{{asset('images/site-image/home/macro-img.svg')}}" alt="">
						</div>
						<h5>Macro Influencer</h5>
					</a>
				</div>
				<div class="feature-card influ-feature-card" style="width: 19%">
					<a href="{{ url()->route('category.list', ['type' => 'instagram', 'kind' => 'mid']) }}">
						<div class="feature-vactor position-absolute">
							<img src="{{asset('images/shapes/feature-line-vactor.png')}}" alt="">
						</div>
						<div class="feature-icon">
							<img src="{{asset('images/site-image/home/mid-img.svg')}}" alt="">
						</div>
						<h5>Mid - Tier</h5>
					</a>
				</div>
				<div class="feature-card influ-feature-card " style="width: 19%">
					<a href="{{ url()->route('category.list', ['type' => 'instagram', 'kind' => 'micro']) }}">
						<div class="feature-vactor position-absolute">
							<img src="{{asset('images/shapes/feature-line-vactor.png')}}" alt="">
						</div>
						<div class="feature-icon">
							<img src="{{asset('images/site-image/home/micro-img.svg')}}" alt="">
						</div>
						<h5>Micro Influencer</h5>
					</a>
				</div>
				<div class="feature-card influ-feature-card" style="width: 19%">
					<a href="{{ url()->route('category.list', ['type' => 'instagram', 'kind' => 'nano']) }}">
						<div class="feature-vactor position-absolute">
							<img src="{{asset('images/shapes/feature-line-vactor.png')}}" alt="">
						</div>
						<div class="feature-icon">
							<img src="{{asset('images/site-image/home/nano-img.svg')}}" alt="">
						</div>
						<h5>Nano Influencer</h5>
					</a>
				</div>
			</div>

		</div>
	</div>
</section>

<section class="sub-header-bar-two bg-transparent text-center">

	<div class="justify-content-center">
		<div class="col-lg-12 d-flex justify-content-center align-items-center">
			<div class="swiper-button-prev d-xl-none d-block" tabindex="0" role="button"
				 aria-label="Previous slide">
				<i class="flaticon-arrow-pointing-to-right-fill"></i>
			</div>

			<!-- <div class="before-line d-lg-block d-none"></div> -->
			<!-- <img src="assets/images/left-line.png" alt="left-line picture" class="dividing-line"> -->

			<div class="partner-title">
				<h3 class="h3-title d-flex justify-content-center">
					<div><i class="bi-youtube insta-logo"></i>
					</div>
					اینفلوئنسرهای یوتیوب
				</h3>
			</div>
			<!-- <div class="next-line d-lg-block d-none"></div> -->
			<!-- <img src="assets/images/right-line.png" alt="right-line picture" class="dividing-line"> -->

			<div class="swiper-button-next d-xl-none d-block" tabindex="0" role="button" aria-label="Next slide">
				<i class="flaticon-arrow-pointing-to-left-fill"></i>
			</div>
		</div>
	</div>

	<div class="category-area position-relative">
		<div>
			<div class="swiper-container category-slider container d-xl-none d-block">
				<div class="swiper-wrapper">
					@php
						$photos = [
								'other-img.svg',
								'professional-img.svg',
								'education-img.svg',
								'game-img.svg',
								'streamer-img.svg',
						];
						$count = 0;
					@endphp
					@foreach(\App\Models\Category::where('type', 'youtube')->orderBy('id', 'desc')->get() as $category)

						<div class="swiper-slide">
							<div class="feature-card influ-feature-card">
								<a href="{{ url()->route('influencers.list', ['type' => 'youtube', 'category' => $category->id]) }}">
									<div class="feature-vactor position-absolute">
										<img src="{{asset('/images/shapes/feature-line-vactor.png')}}" alt="">
									</div>
									<div class="feature-icon">
										<img src="{{asset('images/site-image/home/'. $photos[$count++])}}" alt="">
									</div>
									<h5 class="mb-3">{{ $category->name }}</h5>
								</a>
							</div>
						</div>

					@endforeach
				</div>
			</div>

			<div class="d-xl-flex justify-content-evenly px-2 d-none">
				@php($count = 0)
				@foreach(\App\Models\Category::where('type', 'youtube')->orderBy('id', 'desc')->get() as $category)

					<div class="feature-card influ-feature-card" style="width: 19%">
						<a href="{{ url()->route('influencers.list', ['type' => 'youtube', 'category' => $category->id]) }}">
							<div class="feature-vactor position-absolute">
								<img src="{{asset('images/shapes/feature-line-vactor.png')}}" alt="">
							</div>
							<div class="feature-icon">
								<img src="{{asset('images/site-image/home/'. $photos[$count++])}}" alt="">
							</div>
							<h5 class="mb-3">{{$category->name}}</h5>
						</a>
					</div>

				@endforeach

			</div>
		</div>
	</div>

</section>

{{----}}

{{--@foreach(\App\Models\Category::all() as $category)--}}
{{--	<div class="swiper-slide">--}}
{{--		<div class="feature-card influ-feature-card">--}}
{{--			<a href="{{ url()->route('influencers.list', ['type' => 'youtube', 'category' => $category->id]) }}">--}}
{{--				<div class="feature-vactor position-absolute">--}}
{{--					<img src="{{ asset('images/shapes/feature-line-vactor.png') }}" alt="">--}}
{{--				</div>--}}
{{--				<div class="feature-icon">--}}
{{--					<i class="flaticon-delivery-fill"></i>--}}
{{--				</div>--}}
{{--				<h5 class="mb-3"> {{ $category->name }} </h5>--}}
{{--			</a>--}}
{{--		</div>--}}
{{--	</div>--}}
{{--@endforeach--}}

{{----}}

@include('components.indexBlog')

<div class="influ-area-start mt-90 mb-5">
	<div class="container">
		<div class="d-flex justify-content-between align-items-center pb-4 flex-sm-row flex-column">
			<div class="section-title d-flex mb-sm-0 mb-3">

				<div class="d-flex align-items-center justify-content-center text-center">
					<h2 class="ms-2 box-title">اینفلوئنسر های پربازدید</h2>
				</div>
			</div>
			<div class="show-more d-flex justify-content-between align-items-center text-center">
				<a href="{{ url()->route('influencers.list', ['sort' => 'seen']) }}" class="show-more-button d-flex text-center">
					<h6 class="ms-1 text-black">مشاهده بیشتر</h6>
					<i class="bi bi-caret-left-fill"></i>
				</a>
			</div>
		</div>
		<div class="row">
			@foreach($sortBySeenInflu as $influ)
			<div class="col-lg-3 col-md-6 mb-lg-0 mb-5 col-sm-6">
				<div class="influ-card d-flex justify-content-center flex-column align-items-center">
					<div class="influ-thumb">
						<a href="{{ url()->route('influencers.single.page', ['id' => $influ->id]) }}">
							@if(!empty($influ->photo) && ($influ->photo) != 'profiles/')
							<img class="influ-image" src="{{ \Illuminate\Support\Facades\Storage::url($influ->photo) }}"
								 alt="influ image">
							@else
								<h3 class="non-img-h3 text-center mt-70"> بدون تصویر </h3>
							@endif

						</a>
					</div>
					<div class="influ-content text-center">
						<div class="influ-text">
							<a href="#" class="product-title">{{ $influ->f_name }}</a>
						</div>
						<div>
							<p>{{ $influ->seen }} عدد بازدید</p>
						</div>
					</div>
				</div>
			</div>
			@endforeach

		</div>
	</div>
</div>

<div class="influ-area-start mt-90 mb-5">
	<div class="container">
		<div class="d-flex justify-content-between align-items-center pb-4 flex-lg-row flex-column">
			<div class="section-title d-flex mb-lg-0 mb-3">

				<div class="d-flex align-items-sm-center justify-content-center text-center flex-sm-row flex-column">
					<h2 class="ms-2 box-title d-flex align-items-center">اینفلوئنسر های پربازده</h2>
					<p style="padding-top: 5px;">(طبق نظرات کاربران ویژه)</p>
				</div>
			</div>
			<div class="show-more d-flex justify-content-between align-items-center text-center">
				<a href="{{ url()->route('influencers.list', ['sort' => 'rate']) }}" class="show-more-button d-flex text-center">
					<h6 class="ms-1 text-black">مشاهده بیشتر</h6>
					<i class="bi bi-caret-left-fill"></i>
				</a>
			</div>
		</div>
		<div class="row">

			@foreach($popularInflu as $influ)

			<div class="col-lg-3 col-md-6 mb-lg-0 mb-5 col-sm-6">
				<div class="influ-card d-flex justify-content-center flex-column align-items-center">
					<div class="influ-thumb">
						<a href="{{ url()->route('influencers.single.page', ['id' => $influ->id]) }}">
							@if(!empty($influ->photo) && ($influ->photo) != 'profiles/')
								<img class="influ-image" src="{{ \Illuminate\Support\Facades\Storage::url('profiles/' . $influ->photo) }}"
									 alt="influ image">
							@else
								<h3 class="non-img-h3 text-center mt-70"> بدون تصویر </h3>
							@endif

						</a>
					</div>
					<div class="influ-content text-center">
						<div class="influ-text">
							<a href="#" class="product-title">{{ $influ->f_name }}</a>
						</div>
						<ul class="d-flex product-rating">
							@php(is_null($influ->rate) ? $influ->rate = 0 : null)
							@php($influ->rate = ($influ->rate ?? 1) / 2)
							@for($i = 0; $i < 5; $i++)
								@if(round($influ->rate) > $i)
									<li><i class="bi bi-star-fill"></i></li>
								@else
									<li><i class="bi bi-star"></i></li>
								@endif
							@endfor
						</ul>
					</div>
				</div>
			</div>

			@endforeach
		</div>
	</div>
</div>

@include('components.map')



<div class="sponsor-logo-area mt-120">
	<div class="container">
		<div class="d-flex justify-content-between align-items-center pb-4 flex-lg-row flex-column">
			<div class="section-title d-flex mb-lg-0 mb-3">
				<div class="d-flex align-items-sm-center justify-content-center text-center flex-sm-row flex-column">
					<h2 class="ms-2 box-title d-flex align-items-center">حامیان ما</h2>
				</div>
			</div>
		</div>
		<div class="row justify-content-center">
			<div class="col-lg-2 col-md-2 col-sm-3 col-6">
				<div class="single-logo">

					<a href="#"><i> <h1 class="text-center"> بزودی ... </h1> </i></a>
				</div>
			</div>
		</div>
{{--			<div class="col-lg-2 col-md-2 col-sm-3 col-6">--}}
{{--				<div class="single-logo">--}}
{{--					<a href="#"><i class="flaticon-massachusetts-institute-of-technology-logotype-fill"></i></a>--}}
{{--				</div>--}}
{{--			</div>--}}
{{--			<div class="col-lg-2 col-md-2 col-sm-3 col-6">--}}
{{--				<div class="single-logo">--}}
{{--					<a href="#"><i class="flaticon-my-life-social-logo-fill"></i></a>--}}
{{--				</div>--}}
{{--			</div>--}}
{{--			<div class="col-lg-2 col-md-2 col-sm-3 col-6">--}}
{{--				<div class="single-logo">--}}
{{--					<a href="#"><i class="flaticon-stanford-university-logo-fill"></i></a>--}}
{{--				</div>--}}
{{--			</div>--}}
{{--			<div class="col-lg-2 col-md-2 col-sm-3 col-6">--}}
{{--				<div class="single-logo">--}}
{{--					<a href="#"><i class="flaticon-club-dante-social-logotype-fill"></i></a>--}}
{{--				</div>--}}
{{--			</div>--}}
{{--			<div class="col-lg-2 col-md-2 col-sm-3 col-6">--}}
{{--				<div class="single-logo">--}}
{{--					<a href="#"><i class="flaticon-funny-or-die-logo-fill"></i></a>--}}
{{--				</div>--}}
{{--			</div>--}}
{{--			<div class="col-lg-2 col-md-2 col-sm-3 col-6">--}}
{{--				<div class="single-logo">--}}
{{--					<a href="#"><i class="flaticon-tuenti-social-logo-fill"></i></a>--}}
{{--				</div>--}}
{{--			</div>--}}
{{--			<div class="col-lg-2 col-md-2 col-sm-3 col-6">--}}
{{--				<div class="single-logo">--}}
{{--					<a href="#"><i class="flaticon-ning-social-logo-fill"></i></a>--}}
{{--				</div>--}}
{{--			</div>--}}
{{--			<div class="col-lg-2 col-md-2 col-sm-3 col-6">--}}
{{--				<div class="single-logo">--}}
{{--					<a href="#"><i class="flaticon-gather-logo-fill"></i></a>--}}
{{--				</div>--}}
{{--			</div>--}}
{{--			<div class="col-lg-2 col-md-2 col-sm-3 col-6">--}}
{{--				<div class="single-logo">--}}
{{--					<a href="#"><i class="flaticon-inside-the-hotel-logotype-fill"></i></a>--}}
{{--				</div>--}}
{{--			</div>--}}
{{--			<div class="col-lg-2 col-md-2 col-sm-3 col-6">--}}
{{--				<div class="single-logo">--}}
{{--					<a href="#"><i class="flaticon-virus-total-text-logo-fill"></i></a>--}}
{{--				</div>--}}
{{--			</div>--}}
{{--			<div class="col-lg-2 col-md-2 col-sm-3 col-6">--}}
{{--				<div class="single-logo">--}}
{{--					<a href="#"><i class="flaticon-blogbus-logo-fill"></i></a>--}}
{{--				</div>--}}
{{--			</div>--}}
{{--		</div>--}}
	</div>
</div>


@endsection
