@extends('layouts.app')

@section('title', 'دسته بندی ها')

@section('content')


    <div class="hero-area position-relative pt-3"></div>
    @include('hemayat')

    <div class="product-area mt-60">
        <div class="container">
            <div class="row justify-content-center mb-5">
                <div class="col-12 d-flex justify-content-center align-items-center">


                    <div>
                        <h3 class="h3-title d-flex justify-content-center">
                            لیست اینفلوئنسرها
                            @php
                                switch (request()->get('type')){
	                                case 'instagram';
	                                    echo 'اینستاگرام';
	                                    break;
                                    case 'youtube':
                                        echo 'یوتیوب';
                                        break;
                                }
                            @endphp
                        </h3>
                    </div>

                </div>

            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="product-tab-buttons">
                        <ul class="nav nav-pills justify-content-center" id="pills-tab" role="tablist">

                            <li class="nav-item" role="presentation">
                                @if(request()->get('type') == 'youtube')
                                    <div class="col-lg-12">
                                        <div class="product-tab-buttons">
                                            <ul class="nav nav-pills justify-content-center" id="pills-tab" role="tablist">
                                            @foreach(\App\Models\Category::where('type', 'youtube')->orderBy('id', 'desc')->get() as $category)

                                                <a href="{{ url(url()->current() . '?type=youtube&category=' . $category->id) }}">
                                                    <li class="nav-item" role="presentation">
                                                        <button class="nav-link  {{ (request()->get('category') == $category->id) ? 'active' : '' }} " id="pills-nano-tab" data-bs-toggle="pill"
                                                                data-bs-target="#pills-nano" type="button" role="tab" aria-controls="pills-nano">
                                                            {{ $category->name }}
                                                        </button>
                                                    </li>
                                                </a>

                                                @endforeach
                                            </ul>
                                        </div>
                                    </div>

                                    @else
                                <button class="nav-link active" id="pills-macro-tab" data-bs-toggle="pill"
                                        data-bs-target="#pills-macro" type="button" role="tab"
                                        aria-controls="pills-profile" aria-selected="true" style="cursor: auto;"> {{ \App\Models\Category::find(request()->get('category')) ? \App\Models\Category::find(request()->get('category'))->name : 'اینفلوئنسرها'  }} </button>
                                @endif
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="tab-content product-tab" id="pills-tabContent">
                        <div class="tab-pane fade show active" id="pills-nano" role="tabpanel"
                             aria-labelledby="pills-nano-tab">
                            <div class="row gy-5">

                                @foreach($details as $detail)

                                    <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                                        <div class="influ-card d-flex justify-content-center flex-column align-items-center">
                                            <div class="influ-thumb">
                                                <a href="{{ url()->route('influencers.single.page', ['id' => $detail->id]) }}">
                                                    @if(!empty($detail->photo) && ($detail->photo) != 'profiles/')
                                                        <img class="influ-image" src="{{ \Illuminate\Support\Facades\Storage::url($detail->photo) }}"
                                                             alt="influ image">
                                                    @else
                                                        <h3 class="non-img-h3 text-center mt-70"> بدون تصویر </h3>
                                                    @endif

                                                </a>
                                            </div>
                                            <div class="influ-content text-center">
                                                <div class="influ-text">
                                                    <a href="#" class="product-title">{{ $detail->f_name }}</a>
                                                </div>
                                                <div>
                                                    <p>{{ $detail->seen }} عدد بازدید</p>
                                                    <ul class="d-flex product-rating">
                                                        @php(is_null($detail->rate) ? $detail->rate = 0 : null)
                                                        @php($detail->rate = ($detail->rate ?? 1) / 2)
                                                        @for($i = 0; $i < 5; $i++)
                                                            @if(round($detail->rate) > $i)
                                                                <li><i class="bi bi-star-fill"></i></li>
                                                            @else
                                                                <li><i class="bi bi-star"></i></li>
                                                            @endif
                                                        @endfor
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                @endforeach

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection