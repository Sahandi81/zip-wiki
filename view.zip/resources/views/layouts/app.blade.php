<!doctype html>
<html lang="en">
@php

$user = \App\Models\User::with(['role', 'blogLikes'])->find(\Illuminate\Support\Facades\Auth::id());
$userDetails = \App\Models\User::with(['role', 'blogLikes'])->find(\Illuminate\Support\Facades\Auth::id());


@endphp


<head>
    <title> @yield('title') </title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="{{ asset('assets/images/favicon.png') }}" type="image/png" sizes="20x20">
    <link rel="stylesheet" href="{{ asset('css/jquery.fancybox.min.css') }}">
    <link rel="stylesheet" href="{{ asset('css/jquery-ui.css') }}">
    <link rel="stylesheet" href="{{ asset('css/swiper.css') }}">
    <link rel="stylesheet" href="{{ asset('font/flaticon.css') }}">
    <link rel="stylesheet" href="{{ asset('css/bootstrap-icons.css') }}">
    <link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
    <link rel="stylesheet" href="{{ asset('css/responsive.css') }}">
    <link rel="stylesheet" href="{{ asset('css/iranmap.min.css') }}">
    @yield('customStyle')
</head>

<body style="@yield('bodyStyle'); background-color: #fff;">
<span class="d-none" id="CityMap"> {{ $map ?? '' }} </span>
<div class="mobil-sidebar d-sm-none">
    <ul class="mobil-sidebar-icons">
        <li class="category-icon"><a href="#"><i class="flaticon-menu"></i></a></li>
        <li class="profile-dropdown">
            <a class="dropdown-toggle" href="#" id="navbarDarkDropdownMenuLink" role="button"
               data-bs-toggle="dropdown" aria-expanded="false">
                <i class="flaticon-user"></i>
            </a>

            <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDarkDropdownMenuLink">
                @if(isset($user))
                    @if($user->plan == 6)
                        <a class="dropdown-item" href="{{ url()->route('admin.dashboard') }}">
                            <i class="bi profile-dropdown-icon bi-person-circle-fill"></i>
                            داشبورد
                        </a>
                        <a class="dropdown-item" href="{{ url()->route('logout') }}">
                            <i class="bi profile-dropdown-icon bi-box-arrow-right-fill"></i>
                            خروج
                        </a>
                    @else
                        <a class="dropdown-item" href="{{ url()->route('user.profile') }}">
                            <i class="bi profile-dropdown-icon bi-person-circle-fill"></i>
                            پروفایل
                        </a>
                        <a class="dropdown-item" href="{{ url()->route('logout') }}">
                            <i class="bi profile-dropdown-icon bi-box-arrow-right-fill"></i>
                            خروج
                        </a>
                    @endif
                @else
                    <a class="dropdown-item" href="{{ url('login') }}">
                        <i class="bi profile-dropdown-icon bi-person-check-fill"></i>
                        ورود
                    </a>
                    <a class="dropdown-item" href="{{ url('register') }}">
                        <i class="bi profile-dropdown-icon bi-pencil-square-fill"></i>
                        ثبت نام
                    </a>
                @endif

            </div>
        </li>
        <li><a href="{{ url('/') }}"><i class="flaticon-instagram"></i></a></li>
        <li><a href="{{ url('/') }}"><i class="flaticon-youtube" style="font-size: 25px;"></i></a></li>
    </ul>
</div>

<div class="category-sidebar">
    <div class="category-sidebar-wrapper ">
        <div class="category-seidebar-top">
            <a href="{{ url('/') }}">
                <img src="{{asset('images/site-image/footer/Logo.svg')}}" class="navbar-logo" alt="nav logo">
            </a>
            <div class="category-close">
                <i class="bi bi-x"></i>
            </div>
        </div>
        <ul class="list-group list-group-flush">
            <li class="list-group-item py-3">
                <a href="{{ url('/') }}" class="side-bar-items">
                    <i class="bi bi-house ms-3"></i>
                    خانه
                </a>
            </li>
            <li class="list-group-item py-3">
                <a href="{{ url('blog') }}" class="side-bar-items">
                    <i class="bi bi-newspaper ms-3"></i>
                    بلاگ و اخبار
                </a>
            </li>
            <li class="list-group-item py-3">
                <a href="{{ url('categories?type=instagram&kind=mega') }}" class="side-bar-items">
                    <i class="bi bi-instagram ms-3"></i>
                    اینفلوئنسرهای اینستاگرام
                </a>
            </li>
            <li class="list-group-item py-3">
                <a href="{{ url('influencers?type=youtube') }}" class="side-bar-items">
                    <i class="bi bi-youtube ms-3"></i>
                    اینفلوئنسرهای یوتیوب
                </a>
            </li>
            <li class="list-group-item py-3">
                <a href="{{ url('about_us') }}" class="side-bar-items">
                    <i class="bi bi-info-circle ms-3"></i>
                    درباره ما
                </a>
            </li>
            <li class="list-group-item py-3">
                <a data-bs-toggle="modal" href="#donateModal">
                    <i class="bi bi-wallet2 ms-3"></i>
                حمایت از ویکی
                </a>
            </li>
{{--            <li class="list-group-item py-3">--}}
{{--                <a href="blog.html" class="side-bar-items">--}}
{{--                    <i class="bi bi-wallet2 ms-3-fill"></i>--}}
{{--                    حمایت از ویکی--}}
{{--                </a>--}}
{{--            </li>--}}
        </ul>
    </div>
</div>

<div class="main-searchbar">
    <div class="searchbar-wrap">
        <div class="container">
            <form action="#" method="POST" class="main-searchbar-form">
                <div class="searchbar-input">
                    <div class="input-wrap w-100 position-relative">
                        <input type="text" placeholder="دنبال چی میگردی؟">
                    </div>
                    <div class="search-close"><i class="flaticon-close-fill"></i></div>
                </div>
            </form>
        </div>
    </div>
</div>

<header>
    <div class="header-area" style="background: linear-gradient(0deg, rgba(0, 0, 0, 0.2), rgba(0, 0, 0, 0.2)),
        linear-gradient(0deg, #078282, #078282)" id="header">
        <div class="container">
            <div class="row">
                <div class="col-xl-2 col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="logo d-flex justify-content-between align-items-center h-100">
                        <div class="category-icon">
                            <a href="javascript:void(0)" style="color: inherit;">
                                <i class="flaticon-menu"></i>
                            </a>
                        </div>
                        <a href="{{ url('/') }}">
                            <img src="{{asset('images/site-image/navbar/Logo.svg')}}" class="navbar-logo" alt="nav logo">
                        </a>
                        <div class="mobile-menu d-flex ">
                            <ul class="d-flex mobil-nav-icons align-items-center">

                                <li><a href="dashboard.html"><i class="flaticon-user-fill"></i></a></li>

                            </ul>

                        </div>
                    </div>
                </div>
                <div class="col-xl-7 col-lg-8 col-md-8 col-sm-6 col-xs-6 d-flex justify-content-start">
                    <nav class="main-nav">
                        <div class="inner-logo d-xl-none">
                            <a href="{{ url('/') }}">
                                <img src="{{asset('images/site-image/navbar/Logo.svg')}}" class="navbar-logo" alt="nav logo">
                            </a>
                        </div>
                        <ul>
                            <li><a href="{{ url('/') }}">خانه</a></li>
                            <li><a href="{{ url('blog') }}">بلاگ و اخبار</a></li>
                            <li><a href="{{ url('categories?type=instagram&kind=mega') }}">اینستاگرام </a></li>
                            <li><a href="{{ url('influencers?type=youtube') }}">یوتیوب</a></li>
                            {{--                            <li><a href="contact.html">تماس با ما</a></li>--}}
                            <li><a href="{{ url('about_us') }}">درباره ما</a></li>
                            <li><a data-bs-toggle="modal" href="#donateModal">حمایت از ویکی</a></li>
                        </ul>
                        <ul class="inner-social-icons d-xl-none d-flex flex-wrap">
                            <li><a href="#"><i class="flaticon-facebook-app-symbol-fill"></i></a></li>
                            <li><a href="#"><i class="flaticon-twitter-1-fill"></i></a></li>
                            <li><a href="#"><i class="flaticon-instagram-2-fill"></i></a></li>
                            <li><a href="#"><i class="flaticon-pinterest-1-fill"></i></a></li>
                        </ul>
                    </nav>
                </div>
                <div class="col-xl-3 col-2 d-none d-xl-block">
                    <div class="nav-right h-100 d-flex align-items-center justify-content-end">
                        <ul class="d-flex nav-icons">



                            <li class="profile-dropdown">
                                <a class="dropdown-toggle btn btn-light" href="#" id="navbarDarkDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false" style="color: #078282;">
                                    <i class="flaticon-user ps-1" style="color: #078282;"></i>

                                        @if(isset($user))
                                            {{ $user->f_name }}
                                        @else
                                            حساب کاربری
                                        @endif
                                </a>
                                <div class="dropdown-menu dropdown-menu-end"
                                     aria-labelledby="navbarDarkDropdownMenuLink">
                                    @if(isset($user))
                                        @if($user->plan == 6)
                                            <a class="dropdown-item" href="{{ url()->route('admin.dashboard') }}">
                                                <i class="bi profile-dropdown-icon bi-person-circle-fill"></i>
                                                داشبورد
                                            </a>
                                            <a class="dropdown-item" href="{{ url()->route('logout') }}">
                                                <i class="bi profile-dropdown-icon bi-box-arrow-right-fill"></i>
                                                خروج
                                            </a>
                                        @else
                                            <a class="dropdown-item" href="{{ url()->route('user.profile') }}">
                                                <i class="bi profile-dropdown-icon bi-person-circle-fill"></i>
                                                پروفایل
                                            </a>
                                            <a class="dropdown-item" href="{{ url()->route('logout') }}">
                                                <i class="bi profile-dropdown-icon bi-box-arrow-right-fill"></i>
                                                خروج
                                            </a>
                                        @endif
                                    @else
                                        <a class="dropdown-item" href="{{ url('login') }}">
                                            <i class="bi profile-dropdown-icon bi-person-check-fill"></i>
                                            ورود
                                        </a>
                                        <a class="dropdown-item" href="{{ url('register') }}">
                                            <i class="bi profile-dropdown-icon bi-pencil-square-fill"></i>
                                            ثبت نام
                                        </a>
                                    @endif

                                </div>
                            </li>
{{--                            <li class="category-icon"><a href="javascript:void(0)"><i class="flaticon-menu"></i></a>--}}
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>




@yield('content')



<!-- Footer -->
<div class="footer-area pt-5">
    <div class="container pt-4">
        <div class="d-flex flex-column justify-content-center align-items-center">

            <div class="footer-about d-flex align-items-center justify-content-center flex-column">
                <img class="footer-logo" src="{{asset('images/site-image/footer/Logo.svg')}}" alt="footer logo">

            </div>

            <div class="footer-widget">
                <div class="footer-links">
                    <ul class="link-list d-flex flex-md-row flex-column align-items-center">
                        <li><a href="{{ url('/') }}">خانه</a></li>
                        <li><a href="{{ url('blog') }}">بلاگ و اخبار</a></li>
                        <li><a href="{{ url('categories?type=instagram&kind=mega') }}">اینستاگرام</a></li>
                        <li><a href="{{ url('influencers?type=youtube') }}">یوتیوب</a></li>
                        <li><a href="{{ url('about_us') }}">درباره ما</a></li>
                        <li><a href="#donateModal" data-bs-toggle="modal">حمایت از ویکی</a></li>
                    </ul>
                </div>
            </div>

            <ul class="footer-contact-list d-flex justify-content-between align-items-center flex-md-row flex-column">
                <li>
                    <div class="contact-icon pt-1"><i class="bi bi-telephone-fill"></i></div>
                    <div class="contact-list">
                        <a href="tel:+98">09194133142</a>
                    </div>
                </li>
                <li class="my-md-0 my-3">
                    <ul class="footer-social-links d-flex">
                        <li><a href="#"><i class="bi bi-twitter"></i></a></li>
                        <li><a href="#"><i class="bi bi-telegram"></i></a></li>
                        <li><a href="#"><i class="bi bi-instagram"></i></a></li>

                    </ul>
                </li>
                <li>
                    <div class="contact-list">
                        <a href="#">info@wikiinflu.com</a>
                    </div>
                    <div class="contact-icon pt-2"><i class="bi bi-envelope-fill"></i></div>
                </li>
            </ul>
        </div>
        <div class="footer-bottom text-center">
            <div class="col-12 ">
                <div class="footer-copyring">
                    <p>تمامی حقوق سایت متعلق به ویکی اینفلو میباشد</p>
                </div>
            </div>
        </div>
    </div>
</div>
<a class="help-icon" href="#"><i class="bi-headphones"></i></a>


<script src="{{ asset('js/jquery-3.6.0.min.js') }}"></script>
<script src="{{ asset('js/bootstrap.bundle.min.js') }}"></script>
<script src="{{ asset('js/jquery-ui.min.js') }}"></script>
<script src="{{ asset('js/swiper.js') }}"></script>
<script src="{{ asset('js/jquery.fancybox.min.js') }}"></script>

<script src="{{ asset('js/main.js') }}"></script>
<script src="{{ asset('js/main-two.js') }}"></script>
<script src="{{ asset('js/header.js') }}"></script>

<script>
    document.querySelector('button[aria-selected=true]').click()
</script>
<script>
    const province = document.querySelectorAll('path[class]');
    const title = document.querySelector('.show-title');

    for (let i = 1; i < province.length; i++) {
        province[i].addEventListener('mouseenter', (item) => {
            const titleText = document.querySelector(`li.${item.target.classList[0]}`);
            title.style.display = "block";
            title.textContent = titleText.textContent;
        })

        province[i].addEventListener('mouseleave', (item) => {
            title.style.display = "none";
            title.textContent = '';
        })
    }

    $('#IranMap').mousemove(function(e) {
        var posx = 0;
        var posy = 0;
        if (!e)
            var e = window.event;
        if (e.pageX || e.pageY) {
            posx = e.pageX;
            posy = e.pageY;
        } else if (e.clientX || e.clientY) {
            posx = e.clientX + document.body.scrollLeft + document.documentElement.scrollLeft;
            posy = e.clientY + document.body.scrollTop + document.documentElement.scrollTop;
        }
        if ($('#IranMap .show-title').html()) {
            var offset = $(this).offset();
            var x = (posx - offset.left + 25) + 'px';
            var y = (posy - offset.top - 5) + 'px';
            $('#IranMap .show-title').css({'left': x, 'top': y});
        }
    });
</script>
</body>

</html>