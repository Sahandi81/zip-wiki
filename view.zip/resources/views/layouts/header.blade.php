
<header>
    <div class="header-area" style="background: linear-gradient(0deg, rgba(0, 0, 0, 0.2), rgba(0, 0, 0, 0.2)),
        linear-gradient(0deg, #078282, #078282)" id="header">
        <div class="container">
            <div class="row">
                <div class="col-xl-2 col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="logo d-flex justify-content-between align-items-center h-100">
                        <div class="category-icon">
                            <a href="javascript:void(0)" style="color: inherit;">
                                <i class="flaticon-menu"></i>
                            </a>
                        </div>
                        <a href="{{ url('/') }}">
                            <img src="{{asset('images/site-image/navbar/Logo.svg')}}" class="navbar-logo" alt="nav logo">
                        </a>
                        <div class="mobile-menu d-flex ">
                            <ul class="d-flex mobil-nav-icons align-items-center">

                                <li><a href="dashboard.html"><i class="flaticon-user-fill"></i></a></li>
                                <li class="category-icon"><a href="javascript:void(0)"><i
                                                class="flaticon-menu"></i></a></li>
                            </ul>

                        </div>
                    </div>
                </div>
                <div class="col-xl-7 col-lg-8 col-md-8 col-sm-6 col-xs-6 d-flex justify-content-start">
                    <nav class="main-nav">
                        <div class="inner-logo d-xl-none">
                            <a href="{{ url('/') }}">
                            <img src="{{asset('images/site-image/navbar/Logo.svg')}}" class="navbar-logo" alt="nav logo">
                            </a>
                        </div>
                        <ul>
                            <li><a href="{{ url('/') }}">خانه</a></li>
                            <li><a href="{{ url('blog') }}">بلاگ و اخبار</a></li>
                            <li><a href="{{ url('categories?type=instagram&kind=mega') }}">اینستاگرام </a></li>
                            <li><a href="{{ url('influencers?type=youtube') }}">یوتیوب</a></li>
                            {{--                            <li><a href="contact.html">تماس با ما</a></li>--}}
                            <li><a href="{{ url('about_us') }}">درباره ما</a></li>
                            <li><a data-bs-toggle="modal" href="#donateModal">حمایت از ویکی</a></li>
                        </ul>
                        <ul class="inner-social-icons d-xl-none d-flex flex-wrap">
                            <li><a href="#"><i class="flaticon-facebook-app-symbol-fill"></i></a></li>
                            <li><a href="#"><i class="flaticon-twitter-1-fill"></i></a></li>
                            <li><a href="#"><i class="flaticon-instagram-2-fill"></i></a></li>
                            <li><a href="#"><i class="flaticon-pinterest-1-fill"></i></a></li>
                        </ul>
                    </nav>
                </div>
                <div class="col-xl-3 col-2 d-none d-xl-block">
                    <div class="nav-right h-100 d-flex align-items-center justify-content-end">
                        <ul class="d-flex nav-icons">


                            <li class="profile-dropdown">
                                <a class="dropdown-toggle btn btn-light" href="#" id="navbarDarkDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false" style="color: #078282;">
                                    <i class="flaticon-user ps-1" style="color: #078282;"></i>
                                    حساب کاربری
                                </a>
                                <div class="dropdown-menu dropdown-menu-end"
                                     aria-labelledby="navbarDarkDropdownMenuLink">
                                    @if(isset($user))
                                        @if($user->plan == 6)
                                            <a class="dropdown-item" href="{{ url()->route('admin.dashboard') }}">
                                                <i class="bi profile-dropdown-icon bi-person-circle-fill"></i>
                                                داشبورد
                                            </a>
                                            <a class="dropdown-item" href="{{ url()->route('logout') }}">
                                                <i class="bi profile-dropdown-icon bi-box-arrow-right-fill"></i>
                                                خروج
                                            </a>
                                        @else
                                            <a class="dropdown-item" href="{{ url()->route('user.profile') }}">
                                                <i class="bi profile-dropdown-icon bi-person-circle-fill"></i>
                                                پروفایل
                                            </a>
                                            <a class="dropdown-item" href="{{ url()->route('logout') }}">
                                                <i class="bi profile-dropdown-icon bi-box-arrow-right-fill"></i>
                                                خروج
                                            </a>
                                        @endif
                                    @else
                                        <a class="dropdown-item" href="{{ url('login') }}">
                                            <i class="bi profile-dropdown-icon bi-person-check-fill"></i>
                                            ورود
                                        </a>
                                        <a class="dropdown-item" href="{{ url('register') }}">
                                            <i class="bi profile-dropdown-icon bi-pencil-square-fill"></i>
                                            ثبت نام
                                        </a>
                                    @endif

                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>