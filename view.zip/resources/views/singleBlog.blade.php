@extends('layouts.app')

@section('title', 'دسته بندی ها')

@section('content')


    <div class="hero-area position-relative" style="padding-bottom: 0;">
        <div>
            <div class="swiper-slide hero-slide-item pb-lg-0 pb-5">
                <div class="container">
                    <div class="row d-flex align-items-center">
                        <div class="col-lg-6 offset-lg-1">
                            <div class="slide-item-content text-lg-end text-center">
                                <h1 class="header-title text-light fw-bold header-texts">WIkIInflu</h1>
                                <h4 class="header-sub-title header-texts">اولین و جامع ترین مرجع<br> اینفلوئنسرهای ایرانی در شبکه های اجتماعی</h4>

                            </div>
                        </div>
                        <div class="col-lg-5 d-flex justify-content-center">
                            <div class="profile-header-image-area d-lg-flex d-none justify-content-lg-end">
                                <img src="{{asset('images/site-image/blog/blog-header-image.svg')}} " alt="profile header image" class="img-fluid profile-header-image figure">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    @include('hemayat')
    <main>
        <div class="blog-details-wrapper mt-60">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8">
                        <div class="blog-details shadow-sm py-4 px-3">
                            <div class="blog-head">
                                <ul class="blogl-top d-flex justify-content-center">
                                    <li><a>{{ $blog->title }}</a></li>
                                    <li><a> {{ jdate(strtotime($blog->created_at))->format('d F Y') }} </a></li>
                                </ul>
                                <h3 class="blogl-title"><a href="#">{{ $blog->slug }}</a>
                                </h3>
                            </div>
                            <div class="blog-details-thumb">
                                @if(!empty($blog->photo) && ($blog->photo) != 'blogs/')
                                    <img src="{{ \Illuminate\Support\Facades\Storage::url($blog->photo) }}" alt="">
                                @endif
                            </div>
                            <p>
                              {!! $blog->body  !!}
                            </p>

                            <div class="blog-d-bottom pb-0 border-bottom-0">
                                <div class="col-xl-4 col-md-4 justify-content-xl-center text-secondary d-flex">
                                    <i class="bi bi-eye pt-0 ms-2 fs-6-fill"></i>
                                    <h6>
                                        <span class="ms-2">{{ $blog->id }}</span>
                                        بازدید
                                    </h6>
                                </div>
                                <div class="blog-page-switcher">
                                    <a href="{{ url()->route('blog.single.page', $blog->id + 1) }}"> <i class="flaticon-arrow-pointing-to-right-fill"></i> پست بعدی</a>
                                    <a href="{{ url()->route('blog.single.page', $blog->id - 1) }}"> پست قبلی <i class="flaticon-arrow-pointing-to-left-fill"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="blog-sidebar mt-0 shadow-sm py-5 px-3">
                            <div class="row">
                                <div class="bs-posts mt-0">
                                    <h5 class="bs-title">آخرین پست</h5>
                                    <ul class="bs-post-list">

                                        @foreach(\App\Models\Blog::all()->sortDesc()->take(4) as $blog)
                                            <li class="bs-single-post">
                                                <div class="post-thumb">
                                                    <img src="{{ \Illuminate\Support\Facades\Storage::url($blog->photo) }}" alt="">
                                                </div>
                                                <div class="post-details">
                                                    <h4 class="post-title"><a href="{{ url()->route('blog.single.page', $blog->id) }}"> {{ $blog->title }} </a></h4>
                                                    <p class="post-date"> {{ $blog->created_at }} </p>
                                                </div>
                                            </li>
                                        @endforeach

                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

@endsection