@extends('layouts.app')

@section('title', 'پروفایل من' )

@section('content')

    <div class="hero-area position-relative" style="padding-bottom: 0;">

        <div>
            <div class="swiper-slide hero-slide-item pb-lg-0 pb-5">
                <div class="container">
                    <div class="row d-flex align-items-center">
                        <div class="col-lg-6 offset-lg-1">
                            <div class="slide-item-content text-lg-start text-center">
                                <h1 class="profile-header-title fw-bold">WIkIInflu</h1>
                                <h4 class="profile-header-text fw-bold">پروفایل</h4>

                            </div>
                        </div>
                        <div class="col-lg-5 d-flex justify-content-center">
                            <div class="profile-header-image-area d-lg-flex d-none justify-content-lg-end">
                                <img src="{{asset('images/hero/blog-header-hero.png')}}" alt="profile header image"
                                     class="img-fluid profile-header-image figure">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    @include('hemayat')

    <main>
        @if(\Illuminate\Support\Facades\Session::has('errors'))
            <div class="alert alert-danger w-25 mx-3" role="alert">
                نام کاربری وجود دارد.
            </div>
        @endif
        @if(\Illuminate\Support\Facades\Session::has('success'))
            <div class="alert alert-success w-25 mx-3" role="alert">
                با موفقیت به روزسانی انجام شد.
            </div>
        @endif

        <div class="dashbord-wrapper mt-90">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xl-3 col-lg-4 col-md-6 col-sm-8">
                        <div class="dashbord-switcher mb-4">
                            <a href="{{ url('logout') }}" class="active"><i class="flaticon-user-fill"></i> پروفایل من </a>
                            <a href="#"><i class="flaticon-logout-fill"></i> خروج</a>
                        </div>
                    </div>
                    <div class="col-xl-8 col-lg-8">
                        <div class="profile-form-wrapper">
                            <h5>اطلاعات حساب</h5>
                            <div class="card">
                                <form action="{{ url()->route('update.profile', ['id', \Illuminate\Support\Facades\Auth::id()]) }}" class="card-body mt-0" method="POST" id="profile-form">
                                    @csrf
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="eg-input-group">
                                                <label for="lname"> ایدی اینستاگرام </label>
                                                <input type="text" id="lname" placeholder="نام کاربری" required=""
                                                       value="{{ $details->name }}" disabled >
                                            </div>
                                        </div>
                                        <div class="col-lg-12">
                                            <div class="eg-input-group">
                                                <label for="email">ایمیل</label>
                                                <input class="form-control text-muted" type="password" name="password" value="1234567"
                                                       aria-label="Disabled input example">
                                            </div>
                                        </div>
{{--                                        <div class="col-lg-12">--}}
{{--                                            <div class="eg-input-group">--}}
{{--                                                <label for="Number">رمز عبور</label>--}}
{{--                                                <input type="password" id="Number" required="" value="example" placeholder="رمز عبور">--}}
{{--                                            </div>--}}
{{--                                        </div>--}}

                                        <div class="col-lg-12">
                                            <div class="mb-0 eg-input-group profile-form-sumbit reg-submit-input d-flex align-items-center justify-content-end">
                                                <input type="submit" id="submite-btn" value="ذخیره تغییرات">
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div class="mt-4">
                                <h5>اینفلوئنسرهای دنبال کرده</h5>
                                <ul class="list-group" style="max-height: 500px; overflow-y: auto;">
                                    @foreach($details->favorites as $influ)
                                        <li class="list-group-item">
                                            <div class="influ-card d-flex justify-content-between align-items-center">
                                                <div class="influ-content text-center">
                                                    <div class="influ-text">
                                                        <a href="{{ url()->route('influencers.single.page', ['id' => $influ->id]) }}" class="product-title">{{ $influ->f_name }}</a>
                                                    </div>
                                                </div>
                                                <div class="influ-followed-thumb">
                                                    <a href="{{ url()->route('influencers.single.page', ['id' => $influ->id]) }}">
                                                        @if(!empty($influ->photo) && ($influ->photo) != 'profiles/')
                                                            <img class="influ-followed-image" src="{{ \Illuminate\Support\Facades\Storage::url($influ->photo) }}" alt="influ image">
                                                        @endif
                                                    </a>
                                                </div>
                                            </div>
                                        </li>
                                    @endforeach
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>


@endsection